import type { Metadata } from "next";
import type { ReactNode } from "react";

export const metadata: Metadata = { title: "Refund Policy" };

export default function RefundPolicyPage() {
  return (
    <div className="mx-auto max-w-prose px-5 py-14">
      <h1 className="font-display text-3xl font-bold text-ink">Refund Policy</h1>

      <div className="mt-8 space-y-6 text-sm leading-relaxed text-ink">
        <Section title="Before your eSIM is delivered">
          If your payment succeeds but your eSIM can&apos;t be provisioned, we don&apos;t lose your order or your
          payment — it&apos;s held safely while we sort it out, and our team is automatically notified. You don&apos;t
          need to do anything; you&apos;ll get an email as soon as it&apos;s ready. If it can&apos;t be resolved, you&apos;ll be
          refunded in full.
        </Section>
        <Section title="After your eSIM is delivered">
          Because an eSIM is a digital product that&apos;s usable the moment it&apos;s issued, we generally can&apos;t offer a
          refund once it&apos;s been delivered and installed — the same principle as other instant-delivery digital
          goods. If your eSIM doesn&apos;t work as described (for example, no coverage in the country you purchased
          it for), contact support and we&apos;ll investigate.
        </Section>
        <Section title="Wrong plan or device incompatibility">
          If you bought a plan for the wrong destination and haven&apos;t installed it yet, contact support promptly
          — we may be able to help before you activate it. Refunds aren&apos;t available for plans purchased for a
          device that turns out not to support eSIM; check compatibility before buying.
        </Section>
        <Section title="How refunds are paid">
          Approved refunds are returned to the original PayPal payment method. You&apos;ll get a confirmation email
          once it&apos;s processed; it can take a few days to appear on your PayPal account.
        </Section>
        <Section title="Requesting a refund">
          Contact support with your order number — see the Contact page.
        </Section>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section>
      <h2 className="font-semibold text-ink">{title}</h2>
      <p className="mt-1 text-muted">{children}</p>
    </section>
  );
}
