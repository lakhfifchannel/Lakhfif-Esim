import type { Metadata } from "next";
import type { ReactNode } from "react";

export const metadata: Metadata = { title: "Terms of Service" };

export default function TermsPage() {
  return (
    <div className="mx-auto max-w-prose px-5 py-14">
      <h1 className="font-display text-3xl font-bold text-ink">Terms of Service</h1>
      <p className="mt-2 text-sm text-muted">Last updated: {new Date().toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" })}</p>

      <div className="mt-8 space-y-6 text-sm leading-relaxed text-ink">
        <Section title="1. What we sell">
          Lakhfif eSIM sells digital eSIM data plans sourced from third-party network providers. Plans are
          delivered electronically — there is no physical SIM card, and nothing is shipped.
        </Section>
        <Section title="2. Payment">
          Payment is processed by PayPal. We never see or store your card or PayPal account credentials. An
          eSIM is provisioned only after your payment has been confirmed.
        </Section>
        <Section title="3. Device compatibility">
          You are responsible for confirming your device supports eSIM and is carrier-unlocked before
          purchasing. We are not able to offer refunds for plans purchased for incompatible or locked devices —
          see our Refund Policy.
        </Section>
        <Section title="4. Data plans and validity">
          Data amounts, validity periods, coverage, and network details are as shown on the plan at the time of
          purchase and are supplied by our underlying network providers. Fair usage policies, where they apply,
          are shown on the plan detail page.
        </Section>
        <Section title="5. Account responsibility">
          You're responsible for keeping your account credentials secure and for all activity under your
          account.
        </Section>
        <Section title="6. Changes">
          We may update these terms from time to time. Continued use of the site after a change means you
          accept the updated terms.
        </Section>
        <Section title="7. Contact">
          Questions about these terms can be sent to our support address — see the Contact page.
        </Section>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section>
      <h2 className="font-semibold text-ink">{title}</h2>
      <p className="mt-1 text-muted">{children}</p>
    </section>
  );
}
