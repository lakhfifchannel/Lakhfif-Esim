import { redirect, notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { getCustomerSession } from "@/lib/auth";
import { env } from "@/lib/env";
import { formatMoney, formatDataAmount } from "@/lib/utils";
import { PayPalButtonClient } from "@/components/PayPalButtonClient";

export default async function CheckoutPage({ params }: { params: Promise<{ planId: string }> }) {
  const { planId } = await params;

  const session = await getCustomerSession();
  if (!session) redirect(`/login?next=${encodeURIComponent(`/checkout/${planId}`)}`);

  const plan = await prisma.plan.findUnique({
    where: { id: planId },
    select: {
      id: true,
      isActive: true,
      dataAmount: true,
      dataUnit: true,
      validityDays: true,
      retailPrice: true,
      currency: true,
      country: { select: { name: true, flagEmoji: true } },
      region: { select: { name: true } },
    },
  });
  if (!plan || !plan.isActive) notFound();

  const place = plan.country?.name ?? plan.region?.name ?? "Multi-country";

  let paypalClientId: string | null = null;
  try {
    paypalClientId = env.paypalClientId;
  } catch {
    paypalClientId = null;
  }

  return (
    <div className="mx-auto max-w-lg px-5 py-12">
      <h1 className="font-display text-2xl font-bold text-ink">Checkout</h1>

      <div className="mt-6 rounded-card border border-line bg-white p-6">
        <div className="flex items-center gap-3">
          <span className="text-2xl leading-none">{plan.country?.flagEmoji ?? "🌍"}</span>
          <div>
            <p className="font-semibold text-ink">{place}</p>
            <p className="text-sm text-muted">
              {formatDataAmount(plan.dataAmount, plan.dataUnit)} · {plan.validityDays} days
            </p>
          </div>
        </div>

        <div className="mt-5 flex items-center justify-between border-t border-line pt-4">
          <span className="text-sm text-muted">Total</span>
          <span className="font-display text-xl font-bold text-ink">
            {formatMoney(plan.retailPrice, plan.currency)}
          </span>
        </div>
        <div className="mt-2 flex items-center justify-between text-sm text-muted">
          <span>Sending confirmation to</span>
          <span>{session.email}</span>
        </div>
      </div>

      <p className="mt-4 text-center text-sm text-muted">
        Your eSIM will be delivered digitally after successful payment.
      </p>

      <div className="mt-6">
        {paypalClientId ? (
          <PayPalButtonClient planId={plan.id} clientId={paypalClientId} currency={plan.currency} />
        ) : (
          <p className="rounded-card border border-line bg-cloud p-4 text-sm text-muted">
            PayPal isn&apos;t configured yet — set PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET in .env (sandbox
            credentials work fine for testing) to enable checkout.
          </p>
        )}
      </div>
    </div>
  );
}
