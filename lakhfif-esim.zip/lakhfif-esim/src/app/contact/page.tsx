"use client";

import { useState, type FormEvent } from "react";

export default function ContactPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [orderNumber, setOrderNumber] = useState("");
  const [message, setMessage] = useState("");
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">("idle");

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setStatus("sending");
    const res = await fetch("/api/contact", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, orderNumber, message }),
    });
    setStatus(res.ok ? "sent" : "error");
  }

  if (status === "sent") {
    return (
      <div className="mx-auto max-w-lg px-5 py-16 text-center">
        <h1 className="font-display text-2xl font-bold text-ink">Message sent</h1>
        <p className="mt-2 text-muted">Thanks — we&apos;ll get back to you by email as soon as we can.</p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-lg px-5 py-14">
      <h1 className="font-display text-2xl font-bold text-ink">Contact us</h1>
      <p className="mt-2 text-muted">Questions about an order, a plan, or anything else — we&apos;re happy to help.</p>

      <form onSubmit={onSubmit} className="mt-6 space-y-4">
        <label className="block">
          <span className="text-sm font-medium text-ink">Name</span>
          <input
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="mt-1 w-full rounded-lg border border-line px-3.5 py-2.5 text-ink outline-none focus-visible:border-horizon"
          />
        </label>
        <label className="block">
          <span className="text-sm font-medium text-ink">Email</span>
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="mt-1 w-full rounded-lg border border-line px-3.5 py-2.5 text-ink outline-none focus-visible:border-horizon"
          />
        </label>
        <label className="block">
          <span className="text-sm font-medium text-ink">Order number (optional)</span>
          <input
            value={orderNumber}
            onChange={(e) => setOrderNumber(e.target.value)}
            placeholder="ORDER-10001"
            className="mt-1 w-full rounded-lg border border-line px-3.5 py-2.5 text-ink outline-none placeholder:text-muted focus-visible:border-horizon"
          />
        </label>
        <label className="block">
          <span className="text-sm font-medium text-ink">Message</span>
          <textarea
            required
            rows={5}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="mt-1 w-full rounded-lg border border-line px-3.5 py-2.5 text-ink outline-none focus-visible:border-horizon"
          />
        </label>
        {status === "error" && <p className="text-sm text-danger">Something went wrong — please try again.</p>}
        <button
          type="submit"
          disabled={status === "sending"}
          className="w-full rounded-full bg-horizon py-3 font-medium text-white hover:bg-horizon-dark disabled:opacity-60"
        >
          {status === "sending" ? "Sending…" : "Send message"}
        </button>
      </form>
    </div>
  );
}
