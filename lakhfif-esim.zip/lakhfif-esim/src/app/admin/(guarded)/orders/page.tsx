import { prisma } from "@/lib/prisma";
import { formatMoney } from "@/lib/utils";
import { RetryOrderButton } from "@/components/RetryOrderButton";
import { RefundOrderButton } from "@/components/RefundOrderButton";

const STATUS_TONE: Record<string, string> = {
  FULFILLED: "bg-signal-light text-signal",
  PROVIDER_PENDING: "bg-amber/20 text-amber-dark",
  PROVIDER_PROCESSING: "bg-amber/20 text-amber-dark",
  PAID: "bg-amber/20 text-amber-dark",
  FAILED: "bg-red-50 text-danger",
  REFUNDED: "bg-cloud text-muted",
};

const REFUNDABLE_STATUSES = new Set(["PAID", "PROVIDER_PROCESSING", "FULFILLED", "PROVIDER_PENDING"]);

export default async function AdminOrdersPage() {
  const orders = await prisma.order.findMany({
    orderBy: { createdAt: "desc" },
    take: 100,
    include: {
      user: { select: { email: true } },
      items: { include: { plan: { include: { country: true } } } },
    },
  });

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink">Orders</h1>

      <div className="mt-6 overflow-x-auto rounded-card border border-line bg-white">
        <table className="w-full min-w-[720px] text-sm">
          <thead>
            <tr className="border-b border-line text-left text-xs text-muted">
              <th className="px-4 py-3 font-medium">Order</th>
              <th className="px-4 py-3 font-medium">Customer</th>
              <th className="px-4 py-3 font-medium">Destination</th>
              <th className="px-4 py-3 font-medium">Total</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium"></th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order.id} className="border-b border-line last:border-0">
                <td className="px-4 py-3 font-medium text-ink">{order.orderNumber}</td>
                <td className="px-4 py-3 text-muted">{order.user.email}</td>
                <td className="px-4 py-3 text-ink">{order.items[0]?.plan.country?.name ?? "Multi-country"}</td>
                <td className="px-4 py-3 text-ink">{formatMoney(order.totalAmount, order.currency)}</td>
                <td className="px-4 py-3">
                  <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${STATUS_TONE[order.status] ?? "bg-cloud text-muted"}`}>
                    {order.status.replace(/_/g, " ").toLowerCase()}
                  </span>
                </td>
                <td className="px-4 py-3 text-right">
                  <div className="flex items-center justify-end gap-2">
                    {(order.status === "PROVIDER_PENDING" || order.status === "PROVIDER_PROCESSING") && (
                      <RetryOrderButton orderId={order.id} />
                    )}
                    {REFUNDABLE_STATUSES.has(order.status) && (
                      <RefundOrderButton orderId={order.id} currency={order.currency} />
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
