import { prisma } from "@/lib/prisma";
import { formatMoney } from "@/lib/utils";

export default async function AdminCustomersPage() {
  const users = await prisma.user.findMany({
    orderBy: { createdAt: "desc" },
    take: 200,
    include: {
      orders: {
        where: { status: { in: ["PAID", "PROVIDER_PROCESSING", "FULFILLED", "PROVIDER_PENDING"] } },
        select: { totalAmount: true, currency: true },
      },
      _count: { select: { orders: true } },
    },
  });

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink">Customers</h1>

      <div className="mt-6 overflow-x-auto rounded-card border border-line bg-white">
        <table className="w-full min-w-[600px] text-sm">
          <thead>
            <tr className="border-b border-line text-left text-xs text-muted">
              <th className="px-4 py-3 font-medium">Name</th>
              <th className="px-4 py-3 font-medium">Email</th>
              <th className="px-4 py-3 font-medium">Joined</th>
              <th className="px-4 py-3 font-medium">Orders</th>
              <th className="px-4 py-3 font-medium">Total spent</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => {
              const spent = user.orders.reduce((sum, o) => sum + o.totalAmount, 0);
              const currency = user.orders[0]?.currency ?? "USD";
              return (
                <tr key={user.id} className="border-b border-line last:border-0">
                  <td className="px-4 py-3 text-ink">{user.name ?? "—"}</td>
                  <td className="px-4 py-3 text-muted">{user.email}</td>
                  <td className="px-4 py-3 text-muted">
                    {user.createdAt.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" })}
                  </td>
                  <td className="px-4 py-3 text-ink">{user._count.orders}</td>
                  <td className="px-4 py-3 text-ink">{formatMoney(spent, currency)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {users.length === 0 && <p className="p-5 text-sm text-muted">No customers yet.</p>}
      </div>
    </div>
  );
}
