import { prisma } from "@/lib/prisma";

const STATUS_TONE: Record<string, string> = {
  PROCESSED: "bg-signal-light text-signal",
  RECEIVED: "bg-amber/20 text-amber-dark",
  FAILED: "bg-red-50 text-danger",
};

export default async function AdminWebhooksPage() {
  const webhooks = await prisma.webhook.findMany({
    orderBy: { receivedAt: "desc" },
    take: 100,
  });

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink">Webhooks</h1>
      <p className="mt-1 text-sm text-muted">
        Every inbound PayPal and provider webhook, most recent first. Each event id is processed at most once —
        a duplicate delivery shows up here only the first time.
      </p>

      <div className="mt-6 overflow-x-auto rounded-card border border-line bg-white">
        <table className="w-full min-w-[720px] text-sm">
          <thead>
            <tr className="border-b border-line text-left text-xs text-muted">
              <th className="px-4 py-3 font-medium">Received</th>
              <th className="px-4 py-3 font-medium">Source</th>
              <th className="px-4 py-3 font-medium">Event type</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium">Error</th>
            </tr>
          </thead>
          <tbody>
            {webhooks.map((wh) => (
              <tr key={wh.id} className="border-b border-line last:border-0 align-top">
                <td className="whitespace-nowrap px-4 py-3 text-muted">
                  {wh.receivedAt.toLocaleString(undefined, { dateStyle: "short", timeStyle: "short" })}
                </td>
                <td className="px-4 py-3 text-ink">{wh.source}</td>
                <td className="px-4 py-3 text-ink">{wh.eventType}</td>
                <td className="px-4 py-3">
                  <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${STATUS_TONE[wh.status] ?? "bg-cloud text-muted"}`}>
                    {wh.status.toLowerCase()}
                  </span>
                </td>
                <td className="max-w-xs truncate px-4 py-3 text-xs text-danger">{wh.errorMessage ?? ""}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {webhooks.length === 0 && <p className="p-5 text-sm text-muted">No webhooks received yet.</p>}
      </div>
    </div>
  );
}
