import { prisma } from "@/lib/prisma";
import { PricingRuleForm } from "@/components/PricingRuleForm";
import { PricingRuleRowActions } from "@/components/PricingRuleRowActions";
import { formatDataAmount } from "@/lib/utils";

export default async function AdminPricingPage() {
  const [rules, countries, regions, providers, plans] = await Promise.all([
    prisma.pricingRule.findMany({ orderBy: [{ priority: "desc" }, { createdAt: "desc" }] }),
    prisma.country.findMany({ select: { id: true, name: true }, orderBy: { name: "asc" } }),
    prisma.region.findMany({ select: { id: true, name: true }, orderBy: { name: "asc" } }),
    prisma.provider.findMany({ select: { id: true, name: true }, orderBy: { name: "asc" } }),
    prisma.plan.findMany({
      select: { id: true, dataAmount: true, dataUnit: true, validityDays: true, country: { select: { name: true } } },
      orderBy: { createdAt: "asc" },
    }),
  ]);

  const countryById = new Map(countries.map((c) => [c.id, c.name]));
  const regionById = new Map(regions.map((r) => [r.id, r.name]));
  const providerById = new Map(providers.map((p) => [p.id, p.name]));
  const planLabel = (id: string) => {
    const plan = plans.find((p) => p.id === id);
    return plan ? `${plan.country?.name ?? "Multi-country"} · ${formatDataAmount(plan.dataAmount, plan.dataUnit)} · ${plan.validityDays}d` : id;
  };

  function targetLabel(rule: (typeof rules)[number]): string {
    switch (rule.scope) {
      case "GLOBAL":
        return "Every plan";
      case "DATA_AMOUNT":
        return `${rule.dataAmountMin ?? "0"}–${rule.dataAmountMax ?? "∞"} GB`;
      case "COUNTRY":
        return rule.scopeRefId ? (countryById.get(rule.scopeRefId) ?? "Unknown country") : "—";
      case "REGION":
        return rule.scopeRefId ? (regionById.get(rule.scopeRefId) ?? "Unknown region") : "—";
      case "PROVIDER":
        return rule.scopeRefId ? (providerById.get(rule.scopeRefId) ?? "Unknown provider") : "—";
      case "PLAN":
        return rule.scopeRefId ? planLabel(rule.scopeRefId) : "—";
      default:
        return "—";
    }
  }

  const planOptions = plans.map((p) => ({
    id: p.id,
    label: `${p.country?.name ?? "Multi-country"} · ${formatDataAmount(p.dataAmount, p.dataUnit)} · ${p.validityDays}d`,
  }));

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink">Pricing rules</h1>
      <p className="mt-1 text-sm text-muted">
        Highest priority wins first; among equal priority, the more specific scope wins (plan &gt; data amount &gt;
        provider/country &gt; region &gt; global). Retail prices recompute automatically after any change.
      </p>

      <div className="mt-6">
        <PricingRuleForm countries={countries} regions={regions} providers={providers} plans={planOptions} />
      </div>

      <div className="mt-6 overflow-x-auto rounded-card border border-line bg-white">
        <table className="w-full min-w-[720px] text-sm">
          <thead>
            <tr className="border-b border-line text-left text-xs text-muted">
              <th className="px-4 py-3 font-medium">Scope</th>
              <th className="px-4 py-3 font-medium">Target</th>
              <th className="px-4 py-3 font-medium">Markup</th>
              <th className="px-4 py-3 font-medium">Priority</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium"></th>
            </tr>
          </thead>
          <tbody>
            {rules.map((rule) => (
              <tr key={rule.id} className="border-b border-line last:border-0">
                <td className="px-4 py-3 text-ink">{rule.scope.replace("_", " ").toLowerCase()}</td>
                <td className="px-4 py-3 text-ink">{targetLabel(rule)}</td>
                <td className="px-4 py-3 text-ink">
                  {rule.markupType === "PERCENTAGE" ? `${rule.markupValue}%` : `${(rule.markupValue / 100).toFixed(2)} (fixed)`}
                </td>
                <td className="px-4 py-3 text-muted">{rule.priority}</td>
                <td className="px-4 py-3">
                  <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${rule.isActive ? "bg-signal-light text-signal" : "bg-cloud text-muted"}`}>
                    {rule.isActive ? "active" : "disabled"}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <PricingRuleRowActions id={rule.id} isActive={rule.isActive} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {rules.length === 0 && <p className="p-5 text-sm text-muted">No pricing rules yet — every plan will price at cost.</p>}
      </div>
    </div>
  );
}
