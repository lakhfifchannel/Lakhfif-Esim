import { prisma } from "@/lib/prisma";
import { formatMoney } from "@/lib/utils";

const PAID_STATUSES = ["PAID", "PROVIDER_PROCESSING", "FULFILLED", "PROVIDER_PENDING", "REFUND_PENDING", "REFUNDED"] as const;
const PENDING_STATUSES = ["PENDING_PAYMENT", "PAYMENT_PROCESSING", "PAID", "PROVIDER_PROCESSING", "PROVIDER_PENDING"] as const;

export default async function AdminDashboardPage() {
  const [paidOrders, fulfilledCount, failedCount, pendingCount, esimsSoldCount, topDestinations] = await Promise.all([
    prisma.order.findMany({
      where: { status: { in: [...PAID_STATUSES] } },
      select: { totalAmount: true, currency: true, items: { select: { unitPriceSnapshot: true, wholesalePriceSnapshot: true } } },
    }),
    prisma.order.count({ where: { status: "FULFILLED" } }),
    prisma.order.count({ where: { status: "FAILED" } }),
    prisma.order.count({ where: { status: { in: [...PENDING_STATUSES] } } }),
    prisma.eSIM.count(),
    prisma.orderItem.groupBy({
      by: ["planId"],
      _count: { planId: true },
      orderBy: { _count: { planId: "desc" } },
      take: 5,
    }),
  ]);

  const currency = paidOrders[0]?.currency ?? "USD";
  const revenue = paidOrders.reduce((sum, o) => sum + o.totalAmount, 0);
  const margin = paidOrders.reduce(
    (sum, o) => sum + o.items.reduce((s, i) => s + (i.unitPriceSnapshot - i.wholesalePriceSnapshot), 0),
    0
  );

  const planIds = topDestinations.map((d) => d.planId);
  const plans = await prisma.plan.findMany({
    where: { id: { in: planIds } },
    select: { id: true, country: { select: { name: true, flagEmoji: true } } },
  });
  const planById = new Map(plans.map((p) => [p.id, p]));

  const stats = [
    { label: "Revenue", value: formatMoney(revenue, currency) },
    { label: "Estimated gross margin", value: formatMoney(margin, currency) },
    { label: "Successful orders", value: fulfilledCount },
    { label: "Pending orders", value: pendingCount },
    { label: "Failed orders", value: failedCount },
    { label: "eSIMs sold", value: esimsSoldCount },
  ];

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink">Dashboard</h1>

      <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3">
        {stats.map((s) => (
          <div key={s.label} className="rounded-card border border-line bg-white p-5">
            <p className="text-xs text-muted">{s.label}</p>
            <p className="mt-1 font-display text-xl font-bold text-ink">{s.value}</p>
          </div>
        ))}
      </div>

      <div className="mt-8 rounded-card border border-line bg-white p-5">
        <p className="text-sm font-semibold text-ink">Top destinations</p>
        {topDestinations.length === 0 ? (
          <p className="mt-2 text-sm text-muted">No orders yet.</p>
        ) : (
          <ul className="mt-3 space-y-2">
            {topDestinations.map((d) => {
              const plan = planById.get(d.planId);
              return (
                <li key={d.planId} className="flex items-center justify-between text-sm">
                  <span className="flex items-center gap-2 text-ink">
                    <span>{plan?.country?.flagEmoji ?? "🌍"}</span>
                    {plan?.country?.name ?? "Unknown"}
                  </span>
                  <span className="text-muted">{d._count.planId} orders</span>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
