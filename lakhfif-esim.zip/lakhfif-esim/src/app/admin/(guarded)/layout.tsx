import type { ReactNode } from "react";
import Link from "next/link";
import { requireAdminSession } from "@/lib/auth";

export default async function AdminGuardedLayout({ children }: { children: ReactNode }) {
  const session = await requireAdminSession(); // redirects to /admin/login if not signed in

  return (
    <div className="min-h-screen bg-cloud">
      <div className="border-b border-line bg-ink">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
          <div className="flex items-center gap-6">
            <Link href="/admin" className="font-display text-sm font-bold text-white">
              Lakhfif eSIM admin
            </Link>
            <nav className="flex items-center gap-4 text-sm text-white/80">
              <Link href="/admin" className="hover:text-white">
                Dashboard
              </Link>
              <Link href="/admin/orders" className="hover:text-white">
                Orders
              </Link>
              <Link href="/admin/pricing" className="hover:text-white">
                Pricing
              </Link>
              <Link href="/admin/customers" className="hover:text-white">
                Customers
              </Link>
              <Link href="/admin/webhooks" className="hover:text-white">
                Webhooks
              </Link>
            </nav>
          </div>
          <form action="/api/auth/logout?kind=admin" method="post" className="flex items-center gap-3">
            <span className="text-xs text-white/60">
              {session.email} · {session.role}
            </span>
            <button type="submit" className="rounded-full border border-white/30 px-3 py-1 text-xs text-white hover:bg-white/10">
              Log out
            </button>
          </form>
        </div>
      </div>
      <div className="mx-auto max-w-6xl px-5 py-8">{children}</div>
    </div>
  );
}
