import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getCustomerSession } from "@/lib/auth";
import { createPendingOrder } from "@/services/order/order.service";
import { createPayPalOrder } from "@/services/payment/paypal";
import { rateLimit, clientKey } from "@/lib/rate-limit";
import { verifyOrigin } from "@/lib/csrf";

const schema = z.object({ planId: z.string().min(1) });

export async function POST(req: NextRequest) {
  if (!verifyOrigin(req)) {
    return NextResponse.json({ error: "Invalid request origin" }, { status: 403 });
  }

  const session = await getCustomerSession();
  if (!session) {
    return NextResponse.json({ error: "Please sign in to continue" }, { status: 401 });
  }

  const { allowed } = rateLimit(`checkout-create:${session.sub}:${clientKey(req)}`, 20, 60_000);
  if (!allowed) {
    return NextResponse.json({ error: "Too many attempts. Try again shortly." }, { status: 429 });
  }

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid input" }, { status: 400 });
  }

  let order;
  try {
    order = await createPendingOrder({ userId: session.sub, planId: parsed.data.planId });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Could not create order" },
      { status: 400 }
    );
  }

  const paypalOrder = await createPayPalOrder(order.totalAmount, order.currency, order.orderNumber);

  return NextResponse.json({
    orderId: order.id,
    orderNumber: order.orderNumber,
    paypalOrderId: paypalOrder.paypalOrderId,
  });
}
