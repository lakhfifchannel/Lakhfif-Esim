import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCustomerSession } from "@/lib/auth";
import { capturePayPalOrder } from "@/services/payment/paypal";
import { markOrderPaid, markOrderPaymentFailed } from "@/services/order/order.service";
import { fulfillOrder } from "@/services/order/fulfillment.service";
import { verifyOrigin } from "@/lib/csrf";

const schema = z.object({ orderId: z.string().min(1), paypalOrderId: z.string().min(1) });

/**
 * The frontend calls this once the PayPal button's approval flow
 * completes — but per spec section 8/14, that approval alone is never
 * treated as confirmation. This route makes its own server-to-server call
 * to PayPal to actually capture the funds, and only PayPal's response to
 * *that* call (plus, redundantly, the PAYPAL webhook — see
 * /api/webhooks/paypal) is what confirms payment and triggers fulfillment.
 */
export async function POST(req: NextRequest) {
  if (!verifyOrigin(req)) {
    return NextResponse.json({ error: "Invalid request origin" }, { status: 403 });
  }

  const session = await getCustomerSession();
  if (!session) {
    return NextResponse.json({ error: "Please sign in to continue" }, { status: 401 });
  }

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid input" }, { status: 400 });
  }
  const { orderId, paypalOrderId } = parsed.data;

  const order = await prisma.order.findUnique({ where: { id: orderId } });
  if (!order || order.userId !== session.sub) {
    return NextResponse.json({ error: "Order not found" }, { status: 404 });
  }

  // Cosmetic/observability only — markOrderPaid below is what actually
  // enforces correctness regardless of whether this update races anyone.
  await prisma.order.updateMany({
    where: { id: order.id, status: "PENDING_PAYMENT" },
    data: { status: "PAYMENT_PROCESSING" },
  });

  const capture = await capturePayPalOrder(paypalOrderId, order.id);

  if (capture.status !== "COMPLETED") {
    await markOrderPaymentFailed(order.id, `PayPal capture status: ${capture.status}`);
    return NextResponse.json({ status: "FAILED" }, { status: 402 });
  }

  await markOrderPaid({
    orderId: order.id,
    paypalOrderId,
    captureId: capture.captureId,
    payerEmail: capture.payerEmail,
    amount: order.totalAmount,
    currency: order.currency,
    rawCapture: capture.raw,
  });

  // Awaited so a serverless deployment target doesn't kill the function
  // before fulfillment finishes; the PayPal webhook independently retries
  // this too, so a timeout here isn't a lost order — see fulfillment.service.ts.
  await fulfillOrder(order.id);

  const finalOrder = await prisma.order.findUniqueOrThrow({ where: { id: order.id } });
  return NextResponse.json({ status: finalOrder.status, orderNumber: finalOrder.orderNumber });
}
