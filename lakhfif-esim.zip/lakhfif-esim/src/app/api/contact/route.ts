import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { env } from "@/lib/env";
import { getEmailProvider } from "@/services/email/providers";
import { rateLimit, clientKey } from "@/lib/rate-limit";
import { verifyOrigin } from "@/lib/csrf";

const schema = z.object({
  name: z.string().min(1).max(200),
  email: z.string().email(),
  orderNumber: z.string().max(50).optional(),
  message: z.string().min(1).max(5000),
});

export async function POST(req: NextRequest) {
  if (!verifyOrigin(req)) {
    return NextResponse.json({ error: "Invalid request origin" }, { status: 403 });
  }

  const { allowed } = rateLimit(`contact:${clientKey(req)}`, 5, 60_000);
  if (!allowed) {
    return NextResponse.json({ error: "Too many messages. Try again in a minute." }, { status: 429 });
  }

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Please fill in all required fields" }, { status: 400 });
  }
  const { name, email, orderNumber, message } = parsed.data;

  const text = `From: ${name} <${email}>\nOrder: ${orderNumber || "—"}\n\n${message}`;
  await getEmailProvider()
    .send({
      to: env.supportEmail,
      subject: `Contact form message from ${name}${orderNumber ? ` (${orderNumber})` : ""}`,
      html: `<p><strong>From:</strong> ${escapeHtml(name)} &lt;${escapeHtml(email)}&gt;</p><p><strong>Order:</strong> ${escapeHtml(orderNumber || "—")}</p><p>${escapeHtml(message).replace(/\n/g, "<br/>")}</p>`,
      text,
    })
    .catch((err) => console.error("contact form email failed", err));

  return NextResponse.json({ ok: true });
}

function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] as string);
}
