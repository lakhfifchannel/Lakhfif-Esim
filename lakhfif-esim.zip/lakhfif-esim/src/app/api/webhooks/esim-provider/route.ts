import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { env } from "@/lib/env";
import { applyAsyncProviderWebhook } from "@/services/order/fulfillment.service";

// A generic payload shape for "the provider is telling us, after the fact,
// how one or more previously-PENDING order items turned out." A real
// aggregator's actual webhook shape and signature scheme will differ —
// adapt the verification and the zod schema below once you've picked one,
// the same way example-aggregator-provider.ts is a template to adapt.
//
// To simulate the mock provider's "*-delay" outcome resolving, POST this
// shape here with X-Provider-Webhook-Secret set to ESIM_PROVIDER_WEBHOOK_SECRET:
//   {
//     "eventId": "test-1",
//     "orderNumber": "ORDER-10001",
//     "providerOrderId": "mock-order-manual-test",
//     "items": [{ "referenceId": "<OrderItem.id>", "outcome": "SUCCESS",
//                  "providerEsimId": "mock-esim-abc", "iccid": "89440000000000001",
//                  "qrCodeData": "LPA:1$rsp.mock-lakhfif.example$ABC123",
//                  "lpaString": "LPA:1$rsp.mock-lakhfif.example$ABC123",
//                  "smDpAddress": "rsp.mock-lakhfif.example", "activationCode": "ABC123" }]
//   }

const itemSchema = z.object({
  referenceId: z.string(),
  outcome: z.enum(["SUCCESS", "FAILED", "INSUFFICIENT_BALANCE", "PENDING"]),
  providerEsimId: z.string().optional(),
  iccid: z.string().optional(),
  qrCodeData: z.string().optional(),
  lpaString: z.string().optional(),
  smDpAddress: z.string().optional(),
  activationCode: z.string().optional(),
  expiryDate: z.string().optional(),
  errorMessage: z.string().optional(),
});

const payloadSchema = z.object({
  eventId: z.string(),
  orderNumber: z.string(),
  providerOrderId: z.string(),
  items: z.array(itemSchema).min(1),
});

export async function POST(req: NextRequest) {
  if (env.esimProviderWebhookSecret) {
    const provided = req.headers.get("x-provider-webhook-secret");
    if (provided !== env.esimProviderWebhookSecret) {
      return NextResponse.json({ error: "Invalid signature" }, { status: 401 });
    }
  }

  const parsed = payloadSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
  }
  const { eventId, orderNumber, providerOrderId, items } = parsed.data;

  let webhook;
  try {
    webhook = await prisma.webhook.create({
      data: { source: "PROVIDER", eventId, eventType: "order.items_resolved", payload: parsed.data as never, status: "RECEIVED" },
    });
  } catch {
    return NextResponse.json({ ok: true, duplicate: true });
  }

  try {
    const outcome = await applyAsyncProviderWebhook(orderNumber, providerOrderId, items, parsed.data);
    await prisma.webhook.update({
      where: { id: webhook.id },
      data: { status: "PROCESSED", processedAt: new Date() },
    });
    return NextResponse.json({ ok: true, handled: outcome.handled });
  } catch (err) {
    await prisma.webhook.update({
      where: { id: webhook.id },
      data: { status: "FAILED", errorMessage: err instanceof Error ? err.message : String(err) },
    });
    return NextResponse.json({ ok: true, handled: false });
  }
}
