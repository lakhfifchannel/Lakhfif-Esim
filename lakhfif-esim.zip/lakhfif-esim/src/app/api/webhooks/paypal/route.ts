import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyPayPalWebhookSignature } from "@/services/payment/paypal";
import { markOrderPaid, markOrderPaymentFailed, markOrderRefunded } from "@/services/order/order.service";
import { fulfillOrder } from "@/services/order/fulfillment.service";

interface PayPalCaptureResource {
  id: string;
  status: string;
  custom_id?: string;
  amount?: { value: string; currency_code: string };
  payer?: { email_address?: string };
  supplementary_data?: { related_ids?: { order_id?: string } };
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object" || !("id" in body)) {
    return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
  }

  const verified = await verifyPayPalWebhookSignature(
    {
      authAlgo: req.headers.get("paypal-auth-algo") ?? "",
      certUrl: req.headers.get("paypal-cert-url") ?? "",
      transmissionId: req.headers.get("paypal-transmission-id") ?? "",
      transmissionSig: req.headers.get("paypal-transmission-sig") ?? "",
      transmissionTime: req.headers.get("paypal-transmission-time") ?? "",
    },
    body
  ).catch(() => false);

  if (!verified) {
    return NextResponse.json({ error: "Signature verification failed" }, { status: 400 });
  }

  const eventId = (body as { id: string }).id;
  const eventType = (body as { event_type?: string }).event_type ?? "UNKNOWN";
  const resource = (body as { resource?: PayPalCaptureResource }).resource;

  // Idempotency: the unique constraint on eventId means a duplicate
  // delivery of the same event fails here and is treated as already-done
  // rather than reprocessed — PayPal is told 200 either way so it stops
  // retrying, but the actual side effects only ever run once.
  let webhook;
  try {
    webhook = await prisma.webhook.create({
      data: { source: "PAYPAL", eventId, eventType, payload: body as never, status: "RECEIVED" },
    });
  } catch {
    return NextResponse.json({ ok: true, duplicate: true });
  }

  try {
    if (eventType === "PAYMENT.CAPTURE.COMPLETED" && resource?.custom_id) {
      const order = await prisma.order.findUnique({ where: { orderNumber: resource.custom_id } });
      if (order) {
        await markOrderPaid({
          orderId: order.id,
          paypalOrderId: resource.supplementary_data?.related_ids?.order_id ?? resource.id,
          captureId: resource.id,
          payerEmail: resource.payer?.email_address ?? null,
          amount: Math.round(Number(resource.amount?.value ?? "0") * 100),
          currency: resource.amount?.currency_code ?? order.currency,
          rawCapture: body,
        });
        await fulfillOrder(order.id);
      }
    } else if (eventType === "PAYMENT.CAPTURE.DENIED" && resource?.custom_id) {
      const order = await prisma.order.findUnique({ where: { orderNumber: resource.custom_id } });
      if (order) await markOrderPaymentFailed(order.id, "PayPal reported PAYMENT.CAPTURE.DENIED");
    } else if (eventType === "PAYMENT.CAPTURE.REFUNDED" && resource?.custom_id) {
      const order = await prisma.order.findUnique({ where: { orderNumber: resource.custom_id } });
      if (order) {
        await markOrderRefunded(
          order.id,
          Math.round(Number(resource.amount?.value ?? "0") * 100),
          resource.amount?.currency_code ?? order.currency
        );
      }
    }
    // Any other event type is stored above for audit/history and otherwise ignored.

    await prisma.webhook.update({
      where: { id: webhook.id },
      data: { status: "PROCESSED", processedAt: new Date() },
    });
  } catch (err) {
    await prisma.webhook.update({
      where: { id: webhook.id },
      data: { status: "FAILED", errorMessage: err instanceof Error ? err.message : String(err) },
    });
    // Still 200: PayPal will retry a non-2xx response, but a webhook that
    // failed on our side needs admin attention (see /admin/webhooks), not
    // an automatic PayPal retry storm.
  }

  return NextResponse.json({ ok: true });
}
