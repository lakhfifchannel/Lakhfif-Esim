import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requestPasswordReset } from "@/services/auth/password-reset.service";
import { rateLimit, clientKey } from "@/lib/rate-limit";
import { verifyOrigin } from "@/lib/csrf";

const schema = z.object({ email: z.string().email() });

export async function POST(req: NextRequest) {
  if (!verifyOrigin(req)) {
    return NextResponse.json({ error: "Invalid request origin" }, { status: 403 });
  }

  const { allowed } = rateLimit(`forgot-password:${clientKey(req)}`, 5, 60_000);
  if (!allowed) {
    return NextResponse.json({ error: "Too many attempts. Try again in a minute." }, { status: 429 });
  }

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Enter a valid email address" }, { status: 400 });
  }

  await requestPasswordReset(parsed.data.email);

  // Always the same response, whether or not the email has an account —
  // see password-reset.service.ts for why.
  return NextResponse.json({ ok: true });
}
