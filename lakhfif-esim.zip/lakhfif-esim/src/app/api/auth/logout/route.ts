import { NextRequest, NextResponse } from "next/server";
import { destroyCustomerSession, destroyAdminSession } from "@/lib/auth";
import { verifyOrigin } from "@/lib/csrf";

export async function POST(req: NextRequest) {
  if (!verifyOrigin(req)) {
    return NextResponse.json({ error: "Invalid request origin" }, { status: 403 });
  }

  const kind = new URL(req.url).searchParams.get("kind");
  if (kind === "admin") {
    await destroyAdminSession();
    return NextResponse.redirect(new URL("/admin/login", req.url), { status: 303 });
  }
  await destroyCustomerSession();
  return NextResponse.redirect(new URL("/", req.url), { status: 303 });
}
