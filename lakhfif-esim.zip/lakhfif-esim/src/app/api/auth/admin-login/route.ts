import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { verifyPassword, createAdminSession } from "@/lib/auth";
import { rateLimit, clientKey } from "@/lib/rate-limit";
import { verifyOrigin } from "@/lib/csrf";

const schema = z.object({ email: z.string().email(), password: z.string().min(1) });

export async function POST(req: NextRequest) {
  if (!verifyOrigin(req)) {
    return NextResponse.json({ error: "Invalid request origin" }, { status: 403 });
  }

  const { allowed } = rateLimit(`admin-login:${clientKey(req)}`, 10, 60_000);
  if (!allowed) {
    return NextResponse.json({ error: "Too many attempts. Try again in a minute." }, { status: 429 });
  }

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid input" }, { status: 400 });
  }

  const admin = await prisma.adminUser.findUnique({ where: { email: parsed.data.email.toLowerCase() } });
  const genericError = NextResponse.json({ error: "Incorrect email or password" }, { status: 401 });
  if (!admin || !admin.isActive) return genericError;

  const valid = await verifyPassword(parsed.data.password, admin.passwordHash);
  if (!valid) return genericError;

  await createAdminSession(admin);
  return NextResponse.json({ id: admin.id, email: admin.email, role: admin.role });
}
