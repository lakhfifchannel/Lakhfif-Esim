import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getAdminSession } from "@/lib/auth";
import { refreshAllPlanPrices } from "@/services/pricing/pricing.service";
import { logAudit } from "@/services/order/order.service";
import { verifyOrigin } from "@/lib/csrf";

const schema = z.object({
  scope: z.enum(["GLOBAL", "REGION", "COUNTRY", "PROVIDER", "DATA_AMOUNT", "PLAN"]),
  scopeRefId: z.string().optional(),
  dataAmountMin: z.number().optional(),
  dataAmountMax: z.number().optional(),
  markupType: z.enum(["PERCENTAGE", "FIXED"]),
  markupValue: z.number(),
  priority: z.number().int().default(0),
});

export async function POST(req: NextRequest) {
  if (!verifyOrigin(req)) {
    return NextResponse.json({ error: "Invalid request origin" }, { status: 403 });
  }

  const session = await getAdminSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid input" }, { status: 400 });
  }
  const data = parsed.data;

  if (data.scope !== "GLOBAL" && data.scope !== "DATA_AMOUNT" && !data.scopeRefId) {
    return NextResponse.json({ error: "This scope needs a target selected" }, { status: 400 });
  }

  const rule = await prisma.pricingRule.create({
    data: {
      scope: data.scope,
      scopeRefId: data.scopeRefId || null,
      dataAmountMin: data.dataAmountMin,
      dataAmountMax: data.dataAmountMax,
      markupType: data.markupType,
      markupValue: data.markupValue,
      priority: data.priority,
    },
  });

  await logAudit({
    actorType: "ADMIN",
    actorId: session.sub,
    action: "pricing_rule_created",
    entityType: "PricingRule",
    entityId: rule.id,
    metadata: data,
  });

  await refreshAllPlanPrices();

  return NextResponse.json({ rule });
}
