import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getAdminSession } from "@/lib/auth";
import { refreshAllPlanPrices } from "@/services/pricing/pricing.service";
import { logAudit } from "@/services/order/order.service";
import { verifyOrigin } from "@/lib/csrf";

const patchSchema = z.object({ isActive: z.boolean().optional(), priority: z.number().int().optional() });

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!verifyOrigin(req)) {
    return NextResponse.json({ error: "Invalid request origin" }, { status: 403 });
  }

  const session = await getAdminSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  const parsed = patchSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid input" }, { status: 400 });

  const rule = await prisma.pricingRule.update({ where: { id }, data: parsed.data });

  await logAudit({
    actorType: "ADMIN",
    actorId: session.sub,
    action: "pricing_rule_updated",
    entityType: "PricingRule",
    entityId: id,
    metadata: parsed.data,
  });
  await refreshAllPlanPrices();

  return NextResponse.json({ rule });
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!verifyOrigin(req)) {
    return NextResponse.json({ error: "Invalid request origin" }, { status: 403 });
  }

  const session = await getAdminSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  await prisma.pricingRule.delete({ where: { id } });

  await logAudit({
    actorType: "ADMIN",
    actorId: session.sub,
    action: "pricing_rule_deleted",
    entityType: "PricingRule",
    entityId: id,
  });
  await refreshAllPlanPrices();

  return NextResponse.json({ ok: true });
}
