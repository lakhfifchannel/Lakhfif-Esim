import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { env } from "@/lib/env";
import { fulfillOrder } from "@/services/order/fulfillment.service";
import { logAudit } from "@/services/order/order.service";

/**
 * Not tied to an admin session — this is meant to be called by an
 * external scheduler (Vercel Cron, a system crontab hitting curl, etc.),
 * authenticated with CRON_SECRET as a Bearer token instead. Point your
 * host's cron feature at this URL every few minutes.
 *
 * This is the lightweight alternative to a real job queue mentioned in
 * ARCHITECTURE.md — it re-attempts every order that's been sitting in
 * PROVIDER_PENDING (or stuck in PROVIDER_PROCESSING) for a while, using
 * the same idempotent fulfillOrder() as everything else, so it can never
 * double-purchase an item that already succeeded.
 */
export async function POST(req: NextRequest) {
  if (!env.cronSecret) {
    return NextResponse.json({ error: "Not configured" }, { status: 404 });
  }
  const auth = req.headers.get("authorization");
  if (auth !== `Bearer ${env.cronSecret}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  // Space out retries: only pick up orders that haven't changed in the
  // last 5 minutes, so a permanently-broken order isn't hammered against
  // the provider API on every single cron tick.
  const staleThreshold = new Date(Date.now() - 5 * 60 * 1000);
  const staleOrders = await prisma.order.findMany({
    where: {
      status: { in: ["PROVIDER_PENDING", "PROVIDER_PROCESSING"] },
      updatedAt: { lt: staleThreshold },
    },
    select: { id: true, orderNumber: true },
    take: 50, // one sweep per invocation stays bounded; the next cron tick picks up the rest
  });

  const results: { orderNumber: string; status: string }[] = [];
  for (const order of staleOrders) {
    await fulfillOrder(order.id, { allowStaleReclaim: true });
    const updated = await prisma.order.findUniqueOrThrow({ where: { id: order.id }, select: { status: true } });
    results.push({ orderNumber: order.orderNumber, status: updated.status });
  }

  if (staleOrders.length > 0) {
    await logAudit({
      actorType: "SYSTEM",
      action: "cron_sweep_pending",
      entityType: "Order",
      metadata: { count: staleOrders.length, results },
    });
  }

  return NextResponse.json({ swept: staleOrders.length, results });
}
