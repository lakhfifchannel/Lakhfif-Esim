import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getAdminSession } from "@/lib/auth";
import { fulfillOrder } from "@/services/order/fulfillment.service";
import { logAudit } from "@/services/order/order.service";
import { verifyOrigin } from "@/lib/csrf";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!verifyOrigin(req)) {
    return NextResponse.json({ error: "Invalid request origin" }, { status: 403 });
  }

  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const order = await prisma.order.findUnique({ where: { id } });
  if (!order) {
    return NextResponse.json({ error: "Order not found" }, { status: 404 });
  }
  if (!["PROVIDER_PENDING", "PROVIDER_PROCESSING", "PAID"].includes(order.status)) {
    return NextResponse.json(
      { error: `Order is ${order.status}; nothing to retry` },
      { status: 400 }
    );
  }

  await logAudit({
    actorType: "ADMIN",
    actorId: session.sub,
    action: "manual_fulfillment_retry",
    entityType: "Order",
    entityId: order.id,
    orderId: order.id,
  });

  // allowStaleReclaim lets this recover an order genuinely stuck in
  // PROVIDER_PROCESSING (a previous attempt crashed mid-flight) — see
  // fulfillment.service.ts for why that's safe.
  await fulfillOrder(order.id, { allowStaleReclaim: true });

  const updated = await prisma.order.findUniqueOrThrow({ where: { id: order.id } });
  return NextResponse.json({ status: updated.status });
}
