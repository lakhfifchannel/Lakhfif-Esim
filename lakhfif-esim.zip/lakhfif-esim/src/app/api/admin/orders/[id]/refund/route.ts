import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getAdminSession } from "@/lib/auth";
import { refundPayPalCapture } from "@/services/payment/paypal";
import { markOrderRefunded, recordPartialRefund, logAudit } from "@/services/order/order.service";
import { verifyOrigin } from "@/lib/csrf";

const schema = z.object({ amount: z.number().positive().optional() }); // minor units; omit for a full refund

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!verifyOrigin(req)) {
    return NextResponse.json({ error: "Invalid request origin" }, { status: 403 });
  }

  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  if (session.role !== "SUPER_ADMIN" && session.role !== "FINANCE") {
    return NextResponse.json({ error: "Refunds require a Finance or Super Admin role" }, { status: 403 });
  }

  const parsed = schema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid refund amount" }, { status: 400 });
  }

  const { id } = await params;
  const order = await prisma.order.findUnique({
    where: { id },
    include: { payments: { include: { paypalTransaction: true } } },
  });
  if (!order) {
    return NextResponse.json({ error: "Order not found" }, { status: 404 });
  }
  if (order.status === "REFUNDED") {
    return NextResponse.json({ error: "Already fully refunded" }, { status: 400 });
  }

  const requestedAmount = parsed.data.amount ?? order.totalAmount;
  if (requestedAmount > order.totalAmount) {
    return NextResponse.json({ error: "Refund amount can't exceed the order total" }, { status: 400 });
  }
  const isFullRefund = requestedAmount === order.totalAmount;

  const captureId = order.payments.find((p) => p.status === "COMPLETED")?.paypalTransaction?.captureId;
  if (!captureId) {
    return NextResponse.json({ error: "No completed PayPal capture found on this order" }, { status: 400 });
  }

  try {
    const refund = await refundPayPalCapture(
      captureId,
      `${order.id}:${requestedAmount}`,
      isFullRefund ? undefined : { amount: requestedAmount, currency: order.currency }
    );
    if (refund.status !== "COMPLETED") {
      await logAudit({
        actorType: "ADMIN",
        actorId: session.sub,
        action: "refund_pending",
        entityType: "Order",
        entityId: order.id,
        orderId: order.id,
        metadata: { paypalStatus: refund.status, amount: requestedAmount },
      });
      return NextResponse.json({ status: refund.status });
    }

    if (isFullRefund) {
      await markOrderRefunded(order.id, requestedAmount, order.currency);
    } else {
      await recordPartialRefund(order.id, requestedAmount, order.currency);
    }
    return NextResponse.json({ status: isFullRefund ? "REFUNDED" : "PARTIALLY_REFUNDED" });
  } catch (err) {
    await logAudit({
      actorType: "ADMIN",
      actorId: session.sub,
      action: "refund_failed",
      entityType: "Order",
      entityId: order.id,
      orderId: order.id,
      metadata: { error: err instanceof Error ? err.message : String(err), amount: requestedAmount },
    });
    return NextResponse.json({ error: "Refund failed at PayPal — check the order timeline" }, { status: 502 });
  }
}
