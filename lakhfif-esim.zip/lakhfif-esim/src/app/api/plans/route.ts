import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// Fields safe to expose to the frontend. wholesalePrice and providerId are
// deliberately never selected here — see spec section 8 "Do not show
// upstream provider information" / section 22 "Do NOT expose wholesale prices".
const PUBLIC_PLAN_SELECT = {
  id: true,
  dataAmount: true,
  dataUnit: true,
  validityDays: true,
  retailPrice: true,
  currency: true,
  network: true,
  activationType: true,
  supportedDevices: true,
  fairUsagePolicy: true,
  planType: true,
  country: { select: { name: true, code: true, flagEmoji: true, slug: true } },
  region: { select: { name: true, slug: true } },
} as const;

export async function GET(req: NextRequest) {
  const params = req.nextUrl.searchParams;
  const countrySlug = params.get("country") ?? undefined;
  const regionSlug = params.get("region") ?? undefined;
  const minData = params.get("minData") ? Number(params.get("minData")) : undefined;
  const maxValidity = params.get("maxValidity") ? Number(params.get("maxValidity")) : undefined;

  const plans = await prisma.plan.findMany({
    where: {
      isActive: true,
      country: countrySlug ? { slug: countrySlug } : undefined,
      region: regionSlug ? { slug: regionSlug } : undefined,
      dataAmount: minData !== undefined ? { gte: minData } : undefined,
      validityDays: maxValidity !== undefined ? { lte: maxValidity } : undefined,
    },
    select: PUBLIC_PLAN_SELECT,
    orderBy: [{ country: { name: "asc" } }, { retailPrice: "asc" }],
  });

  return NextResponse.json({ plans });
}
