import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;

  const plan = await prisma.plan.findUnique({
    where: { id },
    select: {
      id: true,
      isActive: true,
      dataAmount: true,
      dataUnit: true,
      validityDays: true,
      retailPrice: true,
      currency: true,
      network: true,
      activationType: true,
      supportedDevices: true,
      fairUsagePolicy: true,
      planType: true,
      country: { select: { name: true, code: true, flagEmoji: true, slug: true } },
      region: { select: { name: true, slug: true } },
    },
  });

  if (!plan || !plan.isActive) {
    return NextResponse.json({ error: "Plan not found" }, { status: 404 });
  }
  return NextResponse.json({ plan });
}
