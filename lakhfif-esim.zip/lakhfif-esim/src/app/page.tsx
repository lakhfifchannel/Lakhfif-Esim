import { prisma } from "@/lib/prisma";
import { CountrySearch } from "@/components/CountrySearch";
import { PlanCard } from "@/components/PlanCard";

const POPULAR_CODES = ["US", "GB", "FR", "ES", "IT", "TR", "AE", "MA", "JP", "TH"];

async function getPopularPlans() {
  const plans = await prisma.plan.findMany({
    where: { isActive: true, country: { code: { in: POPULAR_CODES } } },
    select: {
      id: true,
      dataAmount: true,
      dataUnit: true,
      validityDays: true,
      retailPrice: true,
      currency: true,
      network: true,
      country: { select: { name: true, code: true, slug: true, flagEmoji: true } },
    },
    orderBy: { retailPrice: "asc" },
  });

  // Cheapest plan per country, kept in POPULAR_CODES order.
  const byCode = new Map<string, (typeof plans)[number]>();
  for (const plan of plans) {
    const code = plan.country?.code;
    if (code && !byCode.has(code)) byCode.set(code, plan);
  }
  return POPULAR_CODES.map((code) => byCode.get(code)).filter((p): p is NonNullable<typeof p> => Boolean(p));
}

async function getAllCountries() {
  return prisma.country.findMany({
    where: { isActive: true },
    select: { name: true, slug: true, flagEmoji: true },
    orderBy: { name: "asc" },
  });
}

export default async function HomePage() {
  const [popularPlans, countries] = await Promise.all([getPopularPlans(), getAllCountries()]);

  return (
    <div>
      <section className="border-b border-line bg-paper">
        <div className="mx-auto max-w-6xl px-5 py-16 sm:py-20">
          <h1 className="max-w-2xl font-display text-4xl font-bold leading-tight text-ink sm:text-5xl">
            Global eSIM data, anywhere.
          </h1>
          <p className="mt-4 max-w-lg text-lg text-muted">
            Skip the roaming charges and the airport SIM counter. Buy a local data plan before you land, and
            install it in seconds by QR code.
          </p>
          <div className="mt-8">
            <CountrySearch countries={countries} />
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-14">
        <h2 className="font-display text-2xl font-semibold text-ink">Popular destinations</h2>
        <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {popularPlans.map((plan) => (
            <PlanCard key={plan.id} plan={plan} />
          ))}
        </div>
      </section>

      <section className="border-t border-line bg-paper">
        <div className="mx-auto max-w-6xl px-5 py-14">
          <h2 className="font-display text-2xl font-semibold text-ink">How it works</h2>
          <ol className="mt-8 grid grid-cols-1 gap-8 sm:grid-cols-3">
            <li>
              <p className="font-display text-3xl font-bold text-horizon">1</p>
              <p className="mt-2 font-semibold text-ink">Choose your destination</p>
              <p className="mt-1 text-sm text-muted">Pick a data plan for the country or region you&apos;re visiting.</p>
            </li>
            <li>
              <p className="font-display text-3xl font-bold text-horizon">2</p>
              <p className="mt-2 font-semibold text-ink">Pay securely with PayPal</p>
              <p className="mt-1 text-sm text-muted">Your card details never touch our servers.</p>
            </li>
            <li>
              <p className="font-display text-3xl font-bold text-horizon">3</p>
              <p className="mt-2 font-semibold text-ink">Install instantly by QR code</p>
              <p className="mt-1 text-sm text-muted">Scan it in your phone's eSIM settings — no SIM card needed.</p>
            </li>
          </ol>
        </div>
      </section>
    </div>
  );
}
