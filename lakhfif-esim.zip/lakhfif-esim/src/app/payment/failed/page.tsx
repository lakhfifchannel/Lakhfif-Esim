import Link from "next/link";

export default function PaymentFailedPage() {
  return (
    <div className="mx-auto max-w-lg px-5 py-16 text-center">
      <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-red-50 text-2xl">❌</div>
      <h1 className="mt-5 font-display text-2xl font-bold text-ink">Payment didn&apos;t go through</h1>
      <p className="mt-2 text-muted">
        No eSIM has been issued and nothing was charged. You can try again with the same or a different payment
        method.
      </p>
      <div className="mt-8">
        <Link href="/plans" className="rounded-full bg-horizon px-6 py-3 font-medium text-white hover:bg-horizon-dark">
          Browse plans
        </Link>
      </div>
    </div>
  );
}
