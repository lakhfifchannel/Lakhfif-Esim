import Link from "next/link";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { getCustomerSession } from "@/lib/auth";

export default async function PaymentSuccessPage({
  searchParams,
}: {
  searchParams: Promise<{ order?: string }>;
}) {
  const { order: orderNumber } = await searchParams;
  const session = await getCustomerSession();
  if (!session) redirect("/login");

  const order = orderNumber
    ? await prisma.order.findUnique({
        where: { orderNumber },
        include: { items: { include: { plan: true, esims: true } } },
      })
    : null;

  if (!order || order.userId !== session.sub) {
    return (
      <div className="mx-auto max-w-lg px-5 py-16 text-center">
        <h1 className="font-display text-2xl font-bold text-ink">We couldn&apos;t find that order</h1>
        <Link href="/account/orders" className="mt-4 inline-block text-horizon hover:underline">
          View my orders
        </Link>
      </div>
    );
  }

  const isReady = order.status === "FULFILLED";
  const esim = order.items[0]?.esims[0];

  return (
    <div className="mx-auto max-w-lg px-5 py-16 text-center">
      <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-signal-light text-2xl">
        {isReady ? "✅" : "⏳"}
      </div>

      <h1 className="mt-5 font-display text-2xl font-bold text-ink">
        {isReady ? "Your eSIM is ready" : "Payment received"}
      </h1>
      <p className="mt-2 text-muted">
        {isReady
          ? `Order ${order.orderNumber} is ready to install.`
          : "Your payment was received. Your eSIM is being prepared. You will receive it by email when it is ready."}
      </p>

      <div className="mt-8 flex justify-center gap-3">
        {isReady && esim ? (
          <Link
            href={`/account/esims/${esim.id}`}
            className="rounded-full bg-horizon px-6 py-3 font-medium text-white hover:bg-horizon-dark"
          >
            View my eSIM
          </Link>
        ) : (
          <Link
            href="/account/orders"
            className="rounded-full bg-horizon px-6 py-3 font-medium text-white hover:bg-horizon-dark"
          >
            View order status
          </Link>
        )}
      </div>
    </div>
  );
}
