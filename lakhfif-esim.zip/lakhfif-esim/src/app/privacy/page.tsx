import type { Metadata } from "next";
import type { ReactNode } from "react";

export const metadata: Metadata = { title: "Privacy Policy" };

export default function PrivacyPage() {
  return (
    <div className="mx-auto max-w-prose px-5 py-14">
      <h1 className="font-display text-3xl font-bold text-ink">Privacy Policy</h1>
      <p className="mt-2 text-sm text-muted">Last updated: {new Date().toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" })}</p>

      <div className="mt-8 space-y-6 text-sm leading-relaxed text-ink">
        <Section title="What we collect">
          Your email, name, and order history (which plans you bought, for which destinations). We never see
          or store your PayPal login or card details — PayPal handles that directly.
        </Section>
        <Section title="How we use it">
          To create and deliver your eSIM orders, send order and delivery emails, and provide account access to
          your order and eSIM history.
        </Section>
        <Section title="Who we share it with">
          Our payment processor (PayPal) to process payment, and our eSIM network provider to provision your
          eSIM — only the order details needed to fulfill it, never your payment credentials.
        </Section>
        <Section title="Data retention">
          We keep order records for as long as your account is active and as needed for accounting, fraud
          prevention, and legal requirements.
        </Section>
        <Section title="Your rights">
          You can request a copy of your data or ask us to delete your account by contacting support — see the
          Contact page.
        </Section>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section>
      <h2 className="font-semibold text-ink">{title}</h2>
      <p className="mt-1 text-muted">{children}</p>
    </section>
  );
}
