import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { env } from "@/lib/env";
import { PlanCard } from "@/components/PlanCard";

async function getCountry(slug: string) {
  return prisma.country.findUnique({
    where: { slug },
    include: {
      plans: {
        where: { isActive: true },
        select: {
          id: true,
          dataAmount: true,
          dataUnit: true,
          validityDays: true,
          retailPrice: true,
          currency: true,
          network: true,
          country: { select: { name: true, flagEmoji: true } },
        },
        orderBy: { retailPrice: "asc" },
      },
    },
  });
}

export async function generateMetadata({ params }: { params: Promise<{ country: string }> }): Promise<Metadata> {
  const { country: slug } = await params;
  const country = await getCountry(slug);
  if (!country) return {};

  const description = `Compare eSIM data plans for ${country.name}. Buy online, pay with PayPal, and get instant QR-code delivery — no physical SIM needed.`;
  const url = `${env.appUrl}/esim/${country.slug}`;

  return {
    title: `eSIM for ${country.name}`,
    description,
    alternates: { canonical: url },
    openGraph: { title: `eSIM for ${country.name}`, description, url, type: "website" },
  };
}

const FAQS = [
  {
    q: "Do I need to remove my physical SIM?",
    a: "No. An eSIM runs alongside your existing physical SIM, so you can keep your home number active for calls and texts while using the eSIM for data.",
  },
  {
    q: "When should I install it?",
    a: "You can install the eSIM as soon as you receive it, but most plans only start counting validity from first use — check the plan's activation type before you travel.",
  },
  {
    q: "What if my device doesn't support eSIM?",
    a: "Most phones from the last few years do, including iPhone XS or later, Google Pixel 3 or later, and Samsung Galaxy S20 or later. Check your device settings for an eSIM option before buying.",
  },
];

export default async function CountryEsimPage({ params }: { params: Promise<{ country: string }> }) {
  const { country: slug } = await params;
  const country = await getCountry(slug);
  if (!country || !country.isActive) notFound();

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: FAQS.map((f) => ({
      "@type": "Question",
      name: f.q,
      acceptedAnswer: { "@type": "Answer", text: f.a },
    })),
  };

  return (
    <div className="mx-auto max-w-6xl px-5 py-12">
      {/* eslint-disable-next-line react/no-danger */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <div className="flex items-center gap-3 text-muted">
        <span className="text-2xl leading-none">{country.flagEmoji ?? "🌍"}</span>
        <span>eSIM</span>
      </div>
      <h1 className="mt-1 font-display text-3xl font-bold text-ink">eSIM data plans for {country.name}</h1>
      <p className="mt-2 max-w-prose text-muted">
        Stay connected in {country.name} from the moment you land. Buy online, pay with PayPal, and install your
        eSIM instantly by QR code.
      </p>

      {country.plans.length === 0 ? (
        <p className="mt-10 text-muted">Plans for {country.name} aren&apos;t available right now — check back soon.</p>
      ) : (
        <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {country.plans.map((plan) => (
            <PlanCard key={plan.id} plan={plan} />
          ))}
        </div>
      )}

      <section className="mt-14 max-w-prose">
        <h2 className="font-display text-xl font-semibold text-ink">Frequently asked questions</h2>
        <div className="mt-4 space-y-5">
          {FAQS.map((f) => (
            <div key={f.q}>
              <p className="font-medium text-ink">{f.q}</p>
              <p className="mt-1 text-sm text-muted">{f.a}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
