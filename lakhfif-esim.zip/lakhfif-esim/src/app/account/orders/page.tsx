import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { getCustomerSession } from "@/lib/auth";
import { formatMoney, formatDataAmount } from "@/lib/utils";

const STATUS_LABEL: Record<string, string> = {
  PENDING_PAYMENT: "Awaiting payment",
  PAYMENT_PROCESSING: "Processing payment",
  PAID: "Payment confirmed",
  PROVIDER_PROCESSING: "Preparing your eSIM",
  FULFILLED: "Ready",
  PROVIDER_PENDING: "Preparing your eSIM",
  FAILED: "Payment failed",
  REFUND_PENDING: "Refund in progress",
  REFUNDED: "Refunded",
  CANCELLED: "Cancelled",
};

const STATUS_TONE: Record<string, string> = {
  FULFILLED: "bg-signal-light text-signal",
  PROVIDER_PENDING: "bg-amber/20 text-amber-dark",
  PROVIDER_PROCESSING: "bg-amber/20 text-amber-dark",
  PAID: "bg-amber/20 text-amber-dark",
  FAILED: "bg-red-50 text-danger",
};

export default async function OrdersPage() {
  const session = await getCustomerSession();
  const orders = await prisma.order.findMany({
    where: { userId: session!.sub },
    include: { items: { include: { plan: { include: { country: true } } } } },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink">My orders</h1>

      {orders.length === 0 ? (
        <p className="mt-6 text-muted">
          No orders yet.{" "}
          <Link href="/plans" className="text-horizon hover:underline">
            Browse plans
          </Link>
          .
        </p>
      ) : (
        <div className="mt-6 space-y-3">
          {orders.map((order) => {
            const item = order.items[0];
            return (
              <div key={order.id} className="flex items-center justify-between rounded-card border border-line bg-white p-5">
                <div>
                  <p className="font-medium text-ink">{order.orderNumber}</p>
                  <p className="mt-1 text-sm text-muted">
                    {item?.plan.country?.name ?? "Multi-country"} ·{" "}
                    {item ? formatDataAmount(item.plan.dataAmount, item.plan.dataUnit) : ""} ·{" "}
                    {formatMoney(order.totalAmount, order.currency)}
                  </p>
                </div>
                <span
                  className={`rounded-full px-3 py-1 text-xs font-medium ${STATUS_TONE[order.status] ?? "bg-cloud text-muted"}`}
                >
                  {STATUS_LABEL[order.status] ?? order.status}
                </span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
