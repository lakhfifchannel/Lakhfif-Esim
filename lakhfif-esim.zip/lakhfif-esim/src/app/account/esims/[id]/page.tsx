import { notFound } from "next/navigation";
import QRCode from "qrcode";
import { prisma } from "@/lib/prisma";
import { getCustomerSession } from "@/lib/auth";
import { getESIMProvider } from "@/services/esim/provider.factory";
import { formatDataAmount } from "@/lib/utils";
import { QRCodeDisplay } from "@/components/QRCodeDisplay";

const INSTALL_STEPS: Record<string, string[]> = {
  iPhone: [
    "Go to Settings → Cellular → Add eSIM.",
    "Choose \"Use QR Code\" and scan the code below.",
    "Follow the prompts, then label the plan (e.g. \"Travel\") and set it as your data line.",
  ],
  "Samsung Galaxy": [
    "Go to Settings → Connections → SIM manager → Add eSIM.",
    "Scan the QR code below when prompted.",
    "Confirm activation, then set it as your preferred data SIM under Mobile data.",
  ],
  "Google Pixel": [
    "Go to Settings → Network & internet → SIMs → Add SIM.",
    "Tap \"Download a SIM instead?\" and scan the QR code below.",
    "Follow the prompts, then turn on the new eSIM for mobile data.",
  ],
  "Other Android devices": [
    "Look for eSIM or \"Add mobile plan\" under your network/SIM settings — the exact wording varies by manufacturer.",
    "Choose the option to scan a QR code and scan the one below.",
    "Enable the new plan for mobile data once installed.",
  ],
};

export default async function EsimDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const session = await getCustomerSession();

  const esim = await prisma.eSIM.findUnique({
    where: { id },
    include: {
      order: true,
      orderItem: { include: { plan: { include: { country: true } } } },
    },
  });

  if (!esim || esim.order.userId !== session!.sub) notFound();

  const plan = esim.orderItem.plan;
  const qrCodeDataUrl = esim.lpaString ? await QRCode.toDataURL(esim.lpaString) : null;

  let usage: { dataUsedMb: number; dataRemainingMb: number | null } | null = null;
  if (esim.providerEsimId) {
    usage = await getESIMProvider()
      .getUsage(esim.providerEsimId)
      .catch(() => null);
  }

  return (
    <div>
      <div className="flex items-center gap-3 text-muted">
        <span className="text-2xl leading-none">{plan.country?.flagEmoji ?? "🌍"}</span>
        <span>{plan.country?.name ?? "Multi-country"}</span>
      </div>
      <h1 className="mt-1 font-display text-2xl font-bold text-ink">
        {formatDataAmount(plan.dataAmount, plan.dataUnit)} · {plan.validityDays} days
      </h1>
      <p className="mt-1 text-sm text-muted">Order {esim.order.orderNumber}</p>

      <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-[280px_1fr]">
        <div>
          {qrCodeDataUrl ? (
            <QRCodeDisplay
              qrCodeDataUrl={qrCodeDataUrl}
              smDpAddress={esim.smDpAddress}
              activationCode={esim.activationCode}
              iccid={esim.iccid}
            />
          ) : (
            <div className="rounded-card border border-line bg-white p-6 text-center text-sm text-muted">
              Your QR code will appear here once your eSIM finishes provisioning.
            </div>
          )}

          {usage && (
            <div className="mt-4 rounded-card border border-line bg-white p-5">
              <p className="text-xs text-muted">Data usage</p>
              <p className="mt-1 font-display text-lg font-semibold text-ink">
                {(usage.dataUsedMb / 1024).toFixed(2)} GB used
                {usage.dataRemainingMb !== null && ` · ${(usage.dataRemainingMb / 1024).toFixed(2)} GB left`}
              </p>
            </div>
          )}
        </div>

        <div>
          <p className="rounded-card bg-cloud p-4 text-sm text-ink">
            Make sure your device supports eSIM before installing. Most iPhone XS/XR and later, Pixel 3 and later,
            and Galaxy S20 and later support eSIM.
          </p>

          <div className="mt-6 space-y-6">
            {Object.entries(INSTALL_STEPS).map(([device, steps]) => (
              <div key={device}>
                <h2 className="font-semibold text-ink">{device}</h2>
                <ol className="mt-2 list-decimal space-y-1 pl-5 text-sm text-muted">
                  {steps.map((step) => (
                    <li key={step}>{step}</li>
                  ))}
                </ol>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
