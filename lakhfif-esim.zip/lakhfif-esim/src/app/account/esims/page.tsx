import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { getCustomerSession } from "@/lib/auth";
import { formatDataAmount } from "@/lib/utils";

export default async function EsimsPage() {
  const session = await getCustomerSession();
  const esims = await prisma.eSIM.findMany({
    where: { order: { userId: session!.sub } },
    include: { orderItem: { include: { plan: { include: { country: true } } } } },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink">My eSIMs</h1>

      {esims.length === 0 ? (
        <p className="mt-6 text-muted">
          No eSIMs yet.{" "}
          <Link href="/plans" className="text-horizon hover:underline">
            Browse plans
          </Link>
          .
        </p>
      ) : (
        <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2">
          {esims.map((esim) => {
            const plan = esim.orderItem.plan;
            return (
              <Link
                key={esim.id}
                href={`/account/esims/${esim.id}`}
                className="ticket transition-shadow hover:shadow-md"
              >
                <div className="ticket__main">
                  <div className="flex items-center gap-2 text-sm text-muted">
                    <span className="text-lg leading-none">{plan.country?.flagEmoji ?? "🌍"}</span>
                    <span>{plan.country?.name ?? "Multi-country"}</span>
                  </div>
                  <p className="mt-2 font-display text-xl font-semibold text-ink">
                    {formatDataAmount(plan.dataAmount, plan.dataUnit)}
                  </p>
                  {esim.expiryDate && (
                    <p className="mt-1 text-sm text-muted">
                      Expires {esim.expiryDate.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" })}
                    </p>
                  )}
                </div>
                <div className="ticket__stub">
                  <span
                    className={`rounded-full px-2.5 py-1 text-xs font-medium ${
                      esim.status === "ACTIVE" ? "bg-signal-light text-signal" : "bg-cloud text-muted"
                    }`}
                  >
                    {esim.status.toLowerCase()}
                  </span>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
