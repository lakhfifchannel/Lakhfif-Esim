import type { ReactNode } from "react";
import { requireCustomerSession } from "@/lib/auth";

export default async function AccountLayout({ children }: { children: ReactNode }) {
  await requireCustomerSession(); // redirects to /login if not signed in
  return <div className="mx-auto max-w-4xl px-5 py-12">{children}</div>;
}
