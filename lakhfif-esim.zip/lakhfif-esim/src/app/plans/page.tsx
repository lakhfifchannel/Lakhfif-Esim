import type { Metadata } from "next";
import { prisma } from "@/lib/prisma";
import { PlanCard } from "@/components/PlanCard";

export const metadata: Metadata = {
  title: "All eSIM plans",
  description: "Browse eSIM data plans for every destination we cover.",
};

export default async function PlansPage({
  searchParams,
}: {
  searchParams: Promise<{ country?: string; region?: string }>;
}) {
  const { country, region } = await searchParams;

  const [plans, countries] = await Promise.all([
    prisma.plan.findMany({
      where: {
        isActive: true,
        country: country ? { slug: country } : undefined,
        region: region ? { slug: region } : undefined,
      },
      select: {
        id: true,
        dataAmount: true,
        dataUnit: true,
        validityDays: true,
        retailPrice: true,
        currency: true,
        network: true,
        country: { select: { name: true, flagEmoji: true } },
        region: { select: { name: true } },
      },
      orderBy: [{ country: { name: "asc" } }, { retailPrice: "asc" }],
    }),
    prisma.country.findMany({ where: { isActive: true }, select: { name: true, slug: true }, orderBy: { name: "asc" } }),
  ]);

  const activeCountry = countries.find((c) => c.slug === country);

  return (
    <div className="mx-auto max-w-6xl px-5 py-12">
      <h1 className="font-display text-3xl font-bold text-ink">
        {activeCountry ? `eSIM plans for ${activeCountry.name}` : "All eSIM plans"}
      </h1>
      <p className="mt-2 text-muted">{plans.length} plan{plans.length === 1 ? "" : "s"} available</p>

      <div className="mt-6 flex flex-wrap gap-2">
        <a
          href="/plans"
          className={`rounded-full border px-3 py-1.5 text-sm ${!country ? "border-horizon bg-horizon text-white" : "border-line text-ink hover:border-horizon"}`}
        >
          All countries
        </a>
        {countries.map((c) => (
          <a
            key={c.slug}
            href={`/plans?country=${c.slug}`}
            className={`rounded-full border px-3 py-1.5 text-sm ${c.slug === country ? "border-horizon bg-horizon text-white" : "border-line text-ink hover:border-horizon"}`}
          >
            {c.name}
          </a>
        ))}
      </div>

      {plans.length === 0 ? (
        <p className="mt-12 text-muted">No plans match that filter yet. Try another destination.</p>
      ) : (
        <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {plans.map((plan) => (
            <PlanCard key={plan.id} plan={plan} />
          ))}
        </div>
      )}
    </div>
  );
}
