import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { formatMoney, formatDataAmount } from "@/lib/utils";

async function getPlan(id: string) {
  return prisma.plan.findUnique({
    where: { id },
    select: {
      id: true,
      isActive: true,
      dataAmount: true,
      dataUnit: true,
      validityDays: true,
      retailPrice: true,
      currency: true,
      network: true,
      activationType: true,
      supportedDevices: true,
      fairUsagePolicy: true,
      planType: true,
      country: { select: { name: true, flagEmoji: true } },
      region: { select: { name: true } },
    },
  });
}

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
  const { id } = await params;
  const plan = await getPlan(id);
  if (!plan) return {};
  const place = plan.country?.name ?? plan.region?.name ?? "your destination";
  return {
    title: `${formatDataAmount(plan.dataAmount, plan.dataUnit)} for ${place}`,
    description: `${formatDataAmount(plan.dataAmount, plan.dataUnit)} valid ${plan.validityDays} days in ${place}, delivered instantly as an eSIM.`,
  };
}

export default async function PlanDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const plan = await getPlan(id);
  if (!plan || !plan.isActive) notFound();

  const place = plan.country?.name ?? plan.region?.name ?? "Multi-country";

  return (
    <div className="mx-auto max-w-3xl px-5 py-12">
      <div className="flex items-center gap-3 text-muted">
        <span className="text-2xl leading-none">{plan.country?.flagEmoji ?? "🌍"}</span>
        <span>{place}</span>
      </div>
      <h1 className="mt-2 font-display text-3xl font-bold text-ink">
        {formatDataAmount(plan.dataAmount, plan.dataUnit)} · {plan.validityDays} days
      </h1>

      <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-[1fr_260px]">
        <dl className="space-y-4 rounded-card border border-line bg-white p-6">
          <Row label="Data" value={formatDataAmount(plan.dataAmount, plan.dataUnit)} />
          <Row label="Validity" value={`${plan.validityDays} days`} />
          <Row label="Coverage" value={place} />
          {plan.network && <Row label="Network" value={plan.network} />}
          {plan.activationType && <Row label="Activation" value={plan.activationType === "FIRST_USE" ? "Starts on first use" : plan.activationType} />}
          {plan.planType && <Row label="Plan type" value={plan.planType.replace(/_/g, " ").toLowerCase()} />}
          {plan.fairUsagePolicy && <Row label="Fair usage policy" value={plan.fairUsagePolicy} />}
          {plan.supportedDevices.length > 0 && (
            <div>
              <dt className="text-xs text-muted">Supported devices</dt>
              <dd className="mt-1 text-sm text-ink">{plan.supportedDevices.join(", ")}</dd>
            </div>
          )}
        </dl>

        <div className="h-fit rounded-card border border-line bg-white p-6">
          <p className="font-display text-2xl font-bold text-ink">{formatMoney(plan.retailPrice, plan.currency)}</p>
          <p className="mt-1 text-xs text-muted">Delivered digitally after payment — no physical SIM.</p>
          <Link
            href={`/checkout/${plan.id}`}
            className="mt-5 block rounded-full bg-horizon py-3 text-center font-medium text-white hover:bg-horizon-dark"
          >
            Buy this eSIM
          </Link>
          <p className="mt-3 text-xs text-muted">Make sure your device supports eSIM before purchasing.</p>
        </div>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-line pb-3 last:border-0 last:pb-0">
      <dt className="text-sm text-muted">{label}</dt>
      <dd className="text-right text-sm font-medium capitalize text-ink">{value}</dd>
    </div>
  );
}
