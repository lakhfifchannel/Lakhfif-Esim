import "server-only";
import { prisma } from "@/lib/prisma";
import { env } from "@/lib/env";
import { formatOrderNumber } from "@/lib/utils";
import { computeRetailPrice } from "@/services/pricing/pricing.service";
import { getEmailProvider } from "@/services/email/providers";
import { orderReceivedEmail, paymentSuccessfulEmail, paymentFailedEmail, refundCompletedEmail } from "@/services/email/templates";
import type { ActorType, Order } from "@prisma/client";

export async function logAudit(params: {
  actorType: ActorType;
  actorId?: string | null;
  action: string;
  entityType: string;
  entityId?: string | null;
  orderId?: string | null;
  metadata?: Record<string, unknown>;
}): Promise<void> {
  await prisma.auditLog.create({
    data: {
      actorType: params.actorType,
      actorId: params.actorId ?? null,
      action: params.action,
      entityType: params.entityType,
      entityId: params.entityId ?? null,
      orderId: params.orderId ?? null,
      metadata: (params.metadata ?? undefined) as never,
    },
  });
}

/** Creates the internal order in PENDING_PAYMENT before we ever talk to
 * PayPal, and snapshots the retail price computed right now — so a
 * pricing-rule change five minutes later can never alter what this
 * customer pays (spec section 5). Quantity is fixed at 1: the schema
 * supports multi-unit line items (OrderItem.quantity, one-to-many to
 * ESIM) for later, but checkout only ever creates single-eSIM lines today. */
export async function createPendingOrder(params: {
  userId: string;
  planId: string;
}): Promise<Order> {
  const plan = await prisma.plan.findUnique({ where: { id: params.planId }, include: { country: true } });
  if (!plan || !plan.isActive) {
    throw new Error("Plan not found or no longer available");
  }

  const unitPrice = await computeRetailPrice(plan);

  const order = await prisma.$transaction(async (tx) => {
    const counter = await tx.counter.upsert({
      where: { name: "order_number" },
      update: { value: { increment: 1 } },
      create: { name: "order_number", value: 10001 },
    });

    return tx.order.create({
      data: {
        orderNumber: formatOrderNumber(counter.value),
        userId: params.userId,
        status: "PENDING_PAYMENT",
        currency: plan.currency,
        totalAmount: unitPrice,
        items: {
          create: [
            {
              planId: plan.id,
              quantity: 1,
              unitPriceSnapshot: unitPrice,
              wholesalePriceSnapshot: plan.wholesalePrice,
              currency: plan.currency,
            },
          ],
        },
      },
      include: { items: true },
    });
  });

  await logAudit({
    actorType: "CUSTOMER",
    actorId: params.userId,
    action: "order_created",
    entityType: "Order",
    entityId: order.id,
    orderId: order.id,
  });

  const user = await prisma.user.findUniqueOrThrow({ where: { id: params.userId } });
  await getEmailProvider()
    .send(
      orderReceivedEmail({
        to: user.email,
        orderNumber: order.orderNumber,
        country: plan.country?.name ?? "your destination",
        dataAmount: plan.dataAmount,
        dataUnit: plan.dataUnit,
        validityDays: plan.validityDays,
        amount: unitPrice,
        currency: plan.currency,
      })
    )
    .catch((err) => console.error("orderReceivedEmail failed", err));

  return order;
}

/**
 * The single, idempotent entry point for "payment is confirmed" — called
 * from both the PayPal capture route and the PayPal webhook route,
 * whichever reaches us first or if both do concurrently. Uses a
 * conditional updateMany() (not read-then-write) as the atomic claim, so
 * a race between the two callers can never double-record the payment.
 * `claimed: false` means some other call already handled this order;
 * callers should still proceed to fulfillOrder() regardless, since that
 * has its own independent idempotency guard.
 */
export async function markOrderPaid(params: {
  orderId: string;
  paypalOrderId: string;
  captureId: string | null;
  payerEmail: string | null;
  amount: number;
  currency: string;
  rawCapture: unknown;
}): Promise<{ claimed: boolean; order: Order }> {
  const claim = await prisma.order.updateMany({
    where: { id: params.orderId, status: { in: ["PENDING_PAYMENT", "PAYMENT_PROCESSING"] } },
    data: { status: "PAID" },
  });

  const order = await prisma.order.findUniqueOrThrow({ where: { id: params.orderId } });

  if (claim.count === 0) {
    return { claimed: false, order };
  }

  const payment = await prisma.payment.create({
    data: {
      orderId: order.id,
      provider: "PAYPAL",
      status: "COMPLETED",
      amount: params.amount,
      currency: params.currency,
    },
  });

  await prisma.payPalTransaction.upsert({
    where: { paypalOrderId: params.paypalOrderId },
    update: {
      captureId: params.captureId,
      payerEmail: params.payerEmail,
      status: "COMPLETED",
      rawResponse: params.rawCapture as never,
    },
    create: {
      paymentId: payment.id,
      paypalOrderId: params.paypalOrderId,
      captureId: params.captureId,
      payerEmail: params.payerEmail,
      status: "COMPLETED",
      rawResponse: params.rawCapture as never,
    },
  });

  await logAudit({
    actorType: "SYSTEM",
    action: "payment_confirmed",
    entityType: "Order",
    entityId: order.id,
    orderId: order.id,
    metadata: { paypalOrderId: params.paypalOrderId, captureId: params.captureId },
  });

  const user = await prisma.user.findUniqueOrThrow({ where: { id: order.userId } });
  await getEmailProvider()
    .send(
      paymentSuccessfulEmail({
        to: user.email,
        orderNumber: order.orderNumber,
        amount: params.amount,
        currency: params.currency,
      })
    )
    .catch((err) => console.error("paymentSuccessfulEmail failed", err));

  return { claimed: true, order };
}

/** Mirrors markOrderPaid for the failure path — e.g. PayPal reports the
 * capture as DECLINED. Only fires from a not-yet-paid state, so it can
 * never overwrite an order that (via the other race branch) actually did
 * get marked PAID a moment later. */
export async function markOrderPaymentFailed(orderId: string, reason: string): Promise<void> {
  const claim = await prisma.order.updateMany({
    where: { id: orderId, status: { in: ["PENDING_PAYMENT", "PAYMENT_PROCESSING"] } },
    data: { status: "FAILED" },
  });
  if (claim.count === 0) return;

  await logAudit({
    actorType: "SYSTEM",
    action: "payment_failed",
    entityType: "Order",
    entityId: orderId,
    orderId,
    metadata: { reason },
  });

  const order = await prisma.order.findUniqueOrThrow({ where: { id: orderId }, include: { user: true } });
  await getEmailProvider()
    .send(
      paymentFailedEmail({
        to: order.user.email,
        orderNumber: order.orderNumber,
        retryUrl: `${env.appUrl}/plans`,
      })
    )
    .catch((err) => console.error("paymentFailedEmail failed", err));
}

/** Records a completed refund — called from the PayPal refund webhook, and
 * reusable by an admin-initiated refund action. Idempotent: a second
 * REFUNDED webhook for the same order is a no-op past the first. */
export async function markOrderRefunded(orderId: string, amount: number, currency: string): Promise<void> {
  const claim = await prisma.order.updateMany({
    where: { id: orderId, status: { not: "REFUNDED" } },
    data: { status: "REFUNDED" },
  });
  if (claim.count === 0) return;

  await logAudit({
    actorType: "SYSTEM",
    action: "order_refunded",
    entityType: "Order",
    entityId: orderId,
    orderId,
    metadata: { amount, currency },
  });

  const order = await prisma.order.findUniqueOrThrow({ where: { id: orderId }, include: { user: true } });
  await getEmailProvider()
    .send(refundCompletedEmail({ to: order.user.email, orderNumber: order.orderNumber, amount, currency }))
    .catch((err) => console.error("refundCompletedEmail failed", err));
}

/** For a refund smaller than the order total — logs it and emails the
 * customer, but deliberately does NOT change Order.status to REFUNDED
 * (there's no PARTIALLY_REFUNDED state; the order stays in whatever
 * fulfillment state it was in, since the eSIM itself wasn't affected). */
export async function recordPartialRefund(orderId: string, amount: number, currency: string): Promise<void> {
  await logAudit({
    actorType: "ADMIN",
    action: "order_partially_refunded",
    entityType: "Order",
    entityId: orderId,
    orderId,
    metadata: { amount, currency },
  });

  const order = await prisma.order.findUniqueOrThrow({ where: { id: orderId }, include: { user: true } });
  await getEmailProvider()
    .send(refundCompletedEmail({ to: order.user.email, orderNumber: order.orderNumber, amount, currency }))
    .catch((err) => console.error("refundCompletedEmail failed", err));
}
