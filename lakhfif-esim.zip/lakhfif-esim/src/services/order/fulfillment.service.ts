import "server-only";
import QRCode from "qrcode";
import { prisma } from "@/lib/prisma";
import { env } from "@/lib/env";
import { getESIMProvider } from "@/services/esim/provider.factory";
import { ProviderError } from "@/services/esim/types";
import type { ProviderOrderResult, ProviderOrderResultItem } from "@/services/esim/types";
import { getEmailProvider } from "@/services/email/providers";
import { esimReadyEmail, providerDelayEmail } from "@/services/email/templates";
import { logAudit } from "./order.service";
import type { Order, OrderItem, Plan } from "@prisma/client";

type PendingItem = OrderItem & { plan: Plan };

/** Writes a ProviderTransaction per result item and, for SUCCESS outcomes,
 * the resulting ESIM row. Returns the ids of ESIMs created just now (not
 * ones that already existed from an earlier attempt), so the caller knows
 * exactly which ones are new enough to email. */
async function applyProviderResult(
  order: Order,
  pendingItems: PendingItem[],
  result: ProviderOrderResult
): Promise<string[]> {
  const createdEsimIds: string[] = [];

  for (const resultItem of result.items) {
    const orderItem = pendingItems.find((i) => i.id === resultItem.referenceId);
    if (!orderItem) continue; // defensive: provider echoed an id we didn't send

    await prisma.providerTransaction.create({
      data: {
        orderItemId: orderItem.id,
        providerId: orderItem.plan.providerId,
        providerOrderId: result.providerOrderId,
        status: resultItem.outcome,
        rawRequest: { orderNumber: order.orderNumber, providerPlanId: orderItem.plan.providerPlanId } as never,
        rawResponse: result.raw as never,
      },
    });

    if (resultItem.outcome === "SUCCESS") {
      const esim = await prisma.eSIM.create({
        data: {
          orderId: order.id,
          orderItemId: orderItem.id,
          providerId: orderItem.plan.providerId,
          providerEsimId: resultItem.providerEsimId,
          iccid: resultItem.iccid,
          qrCodeData: resultItem.qrCodeData,
          lpaString: resultItem.lpaString,
          smDpAddress: resultItem.smDpAddress,
          activationCode: resultItem.activationCode,
          status: "PROVISIONED",
          expiryDate: resultItem.expiryDate ? new Date(resultItem.expiryDate) : null,
        },
      });
      createdEsimIds.push(esim.id);
    } else {
      await logAudit({
        actorType: "SYSTEM",
        action: "provider_item_not_fulfilled",
        entityType: "OrderItem",
        entityId: orderItem.id,
        orderId: order.id,
        metadata: { outcome: resultItem.outcome, errorMessage: resultItem.errorMessage },
      });
    }
  }

  return createdEsimIds;
}

/** Re-checks whether every item on the order now has an ESIM and moves the
 * order to FULFILLED or PROVIDER_PENDING accordingly, emailing the
 * customer either way. Only the ESIMs listed in `newlyCreatedEsimIds` are
 * emailed — an ESIM delivered in an earlier attempt is never re-sent just
 * because a later retry finished off the rest of the order. */
async function finalizeOrder(orderId: string, newlyCreatedEsimIds: string[]): Promise<void> {
  const order = await prisma.order.findUniqueOrThrow({
    where: { id: orderId },
    include: { user: true, items: { include: { plan: { include: { country: true } }, esims: true } } },
  });
  const allFulfilled = order.items.every((item) => item.esims.length > 0);

  if (allFulfilled) {
    await prisma.order.update({ where: { id: orderId }, data: { status: "FULFILLED" } });

    for (const item of order.items) {
      for (const esim of item.esims) {
        if (!newlyCreatedEsimIds.includes(esim.id) || !esim.lpaString) continue;
        const qrCodeDataUrl = await QRCode.toDataURL(esim.lpaString);
        await getEmailProvider()
          .send(
            esimReadyEmail({
              to: order.user.email,
              orderNumber: order.orderNumber,
              country: item.plan.country?.name ?? "your destination",
              dataAmount: item.plan.dataAmount,
              dataUnit: item.plan.dataUnit,
              validityDays: item.plan.validityDays,
              qrCodeDataUrl,
              manageUrl: `${env.appUrl}/account/esims/${esim.id}`,
            })
          )
          .catch((err) => console.error("esimReadyEmail failed", err));
      }
    }
  } else {
    await prisma.order.update({ where: { id: orderId }, data: { status: "PROVIDER_PENDING" } });
    await logAudit({
      actorType: "SYSTEM",
      action: "order_provider_pending",
      entityType: "Order",
      entityId: orderId,
      orderId,
    });
    // Note: this fires on every attempt that still doesn't fully complete
    // the order (including retries), so an order retried several times
    // before succeeding sends more than one "still preparing" email. A
    // real deployment might de-dupe this with a last-notified timestamp;
    // left simple here since it's a minor UX rather than a safety issue.
    await getEmailProvider()
      .send(providerDelayEmail({ to: order.user.email, orderNumber: order.orderNumber }))
      .catch((err) => console.error("providerDelayEmail failed", err));
  }
}

/**
 * Purchases/provisions eSIMs for a paid order from the configured
 * provider (mock or real aggregator — see provider.factory.ts), and is
 * safe to call more than once for the same order:
 *
 *  - The order is only "claimed" for processing from PAID or
 *    PROVIDER_PENDING via a conditional updateMany(), so two concurrent
 *    callers (e.g. the PayPal capture route and the PayPal webhook
 *    firing moments later) can't both start provisioning at once.
 *  - Within an order, only OrderItems that don't already have an ESIM
 *    are sent to the provider — so retrying a partially-failed order
 *    (item A succeeded, item B didn't) never re-purchases item A.
 *
 * On any failure — a provider error, or the provider itself reporting
 * FAILED / INSUFFICIENT_BALANCE / PENDING for an item — the order is left
 * in PROVIDER_PENDING (payment stays recorded, nothing is lost) rather
 * than silently failing. Spec section 15.
 */
export async function fulfillOrder(
  orderId: string,
  opts: { allowStaleReclaim?: boolean } = {}
): Promise<void> {
  // Normally an order can only be claimed from PAID or PROVIDER_PENDING.
  // allowStaleReclaim (used only by the admin "retry" action) additionally
  // allows reclaiming an order stuck in PROVIDER_PROCESSING for more than
  // 5 minutes — i.e. a previous attempt crashed mid-flight and never
  // recorded an outcome. Without this a crash between "claim" and
  // "record result" would leave the order permanently unrecoverable.
  const staleThreshold = new Date(Date.now() - 5 * 60 * 1000);
  const claim = await prisma.order.updateMany({
    where: {
      id: orderId,
      OR: [
        { status: { in: ["PAID", "PROVIDER_PENDING"] } },
        ...(opts.allowStaleReclaim
          ? [{ status: "PROVIDER_PROCESSING" as const, updatedAt: { lt: staleThreshold } }]
          : []),
      ],
    },
    data: { status: "PROVIDER_PROCESSING" },
  });
  if (claim.count === 0) {
    return; // already fulfilled, already in progress elsewhere, or payment not confirmed yet
  }

  const order = await prisma.order.findUniqueOrThrow({
    where: { id: orderId },
    include: { items: { include: { plan: true, esims: true } } },
  });

  const pendingItems = order.items.filter((item) => item.esims.length === 0);

  if (pendingItems.length === 0) {
    await prisma.order.update({ where: { id: order.id }, data: { status: "FULFILLED" } });
    return;
  }

  let createdEsimIds: string[] = [];
  try {
    const provider = getESIMProvider();
    const result = await provider.createOrder({
      referenceId: order.orderNumber,
      items: pendingItems.map((item) => ({
        providerPlanId: item.plan.providerPlanId,
        quantity: item.quantity,
        referenceId: item.id,
      })),
    });
    createdEsimIds = await applyProviderResult(order, pendingItems, result);
  } catch (err) {
    const providerError = err instanceof ProviderError ? err : null;
    await logAudit({
      actorType: "SYSTEM",
      action: "provider_create_order_error",
      entityType: "Order",
      entityId: order.id,
      orderId: order.id,
      metadata: {
        code: providerError?.code ?? "UNKNOWN",
        message: err instanceof Error ? err.message : String(err),
      },
    });
    // Fall through to finalizeOrder() below — payment was already
    // captured and must not be lost just because this attempt errored.
  }

  await finalizeOrder(order.id, createdEsimIds);
}

/**
 * Entry point for a provider that confirms orders asynchronously via its
 * own webhook (spec section 12) rather than in the createOrder() response
 * — this is how a mock "*-delay" test plan's PENDING outcome gets
 * resolved. See /api/webhooks/esim-provider for the expected payload
 * shape. Shares the same claim-then-apply-then-finalize path as
 * fulfillOrder(), so it can't race a concurrent fulfillOrder() call or
 * double-provision an item.
 */
export async function applyAsyncProviderWebhook(
  orderNumber: string,
  providerOrderId: string,
  items: ProviderOrderResultItem[],
  raw: unknown
): Promise<{ handled: boolean }> {
  const order = await prisma.order.findUnique({
    where: { orderNumber },
    include: { items: { include: { plan: true, esims: true } } },
  });
  if (!order) return { handled: false };

  const pendingItems = order.items.filter((item) => item.esims.length === 0);
  if (pendingItems.length === 0) return { handled: true };

  const claim = await prisma.order.updateMany({
    where: { id: order.id, status: { in: ["PAID", "PROVIDER_PENDING"] } },
    data: { status: "PROVIDER_PROCESSING" },
  });
  if (claim.count === 0) return { handled: false };

  const createdEsimIds = await applyProviderResult(order, pendingItems, {
    providerOrderId,
    items,
    raw,
  });
  await finalizeOrder(order.id, createdEsimIds);
  return { handled: true };
}
