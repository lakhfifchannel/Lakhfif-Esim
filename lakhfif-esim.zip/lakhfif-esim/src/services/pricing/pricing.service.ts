import "server-only";
import { prisma } from "@/lib/prisma";
import type { PricingRule, PricingScope } from "@prisma/client";

export interface PricedPlanInput {
  id: string;
  providerId: string;
  countryId: string | null;
  regionId: string | null;
  dataAmount: number;
  wholesalePrice: number;
}

// How specific each scope is, used as the tiebreak when two active rules
// have the same admin-set priority. PLAN is the most specific (a one-off
// override for a single plan); GLOBAL the least (a fallback markup).
const SCOPE_SPECIFICITY: Record<PricingScope, number> = {
  PLAN: 5,
  DATA_AMOUNT: 4,
  PROVIDER: 3,
  COUNTRY: 3,
  REGION: 2,
  GLOBAL: 1,
};

function ruleApplies(rule: PricingRule, plan: PricedPlanInput): boolean {
  switch (rule.scope) {
    case "GLOBAL":
      return true;
    case "PLAN":
      return rule.scopeRefId === plan.id;
    case "PROVIDER":
      return rule.scopeRefId === plan.providerId;
    case "COUNTRY":
      return plan.countryId !== null && rule.scopeRefId === plan.countryId;
    case "REGION":
      return plan.regionId !== null && rule.scopeRefId === plan.regionId;
    case "DATA_AMOUNT":
      return (
        (rule.dataAmountMin ?? -Infinity) <= plan.dataAmount &&
        plan.dataAmount <= (rule.dataAmountMax ?? Infinity)
      );
  }
}

function applyMarkup(wholesalePrice: number, rule: PricingRule): number {
  if (rule.markupType === "PERCENTAGE") {
    return Math.round(wholesalePrice * (1 + rule.markupValue / 100));
  }
  return Math.round(wholesalePrice + rule.markupValue);
}

/**
 * Resolves the retail price for a plan against every active PricingRule.
 * Selection order: highest `priority` wins first; among rules tied on
 * priority (the common case — most admins never touch it), the most
 * specific scope wins (PLAN > DATA_AMOUNT > PROVIDER/COUNTRY > REGION >
 * GLOBAL). Raise a rule's priority to force it to win over a normally
 * more specific one (e.g. a time-limited global promo overriding
 * per-plan overrides).
 *
 * Falls back to wholesalePrice (0% markup) if no rule matches at all, so
 * a plan never silently goes unpriced — but that state is worth alerting
 * on, since it means margin is $0.
 */
export async function computeRetailPrice(plan: PricedPlanInput): Promise<number> {
  const rules = await prisma.pricingRule.findMany({ where: { isActive: true } });
  const applicable = rules.filter((r) => ruleApplies(r, plan));
  if (applicable.length === 0) return plan.wholesalePrice;

  applicable.sort(
    (a, b) =>
      b.priority - a.priority ||
      SCOPE_SPECIFICITY[b.scope] - SCOPE_SPECIFICITY[a.scope]
  );
  return applyMarkup(plan.wholesalePrice, applicable[0]);
}

/** Recomputes and persists Plan.retailPrice's cache for one plan — call
 * after a plan is synced from a provider or after pricing rules change. */
export async function refreshPlanRetailPrice(planId: string): Promise<number> {
  const plan = await prisma.plan.findUniqueOrThrow({ where: { id: planId } });
  const retailPrice = await computeRetailPrice(plan);
  await prisma.plan.update({ where: { id: planId }, data: { retailPrice } });
  return retailPrice;
}

/** Recomputes every active plan's cached retail price. Safe to run after
 * any pricing rule is added, edited, or disabled from the admin panel. */
export async function refreshAllPlanPrices(): Promise<number> {
  const plans = await prisma.plan.findMany({ where: { isActive: true } });
  let updated = 0;
  for (const plan of plans) {
    const retailPrice = await computeRetailPrice(plan);
    if (retailPrice !== plan.retailPrice) {
      await prisma.plan.update({ where: { id: plan.id }, data: { retailPrice } });
      updated++;
    }
  }
  return updated;
}
