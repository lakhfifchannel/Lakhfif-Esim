import "server-only";
import { env } from "@/lib/env";

export interface EmailMessage {
  to: string;
  subject: string;
  html: string;
  text: string;
}

export interface EmailProvider {
  send(message: EmailMessage): Promise<void>;
}

/** Default in dev: logs the email instead of sending it, so the full
 * order -> fulfillment -> "eSIM ready" email flow is testable with zero
 * external configuration. */
class ConsoleEmailProvider implements EmailProvider {
  async send(message: EmailMessage): Promise<void> {
    console.log(
      `\n[email:console] to=${message.to} subject="${message.subject}"\n${message.text}\n`
    );
  }
}

/** Calls Resend's REST API directly (https://resend.com/docs/api-reference/emails/send-email)
 * rather than pulling in their SDK — it's one POST request, so a hand
 * dependency isn't worth an extra package. Swap for any other transactional
 * provider by implementing EmailProvider and adding a case below. */
class ResendEmailProvider implements EmailProvider {
  async send(message: EmailMessage): Promise<void> {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${env.emailApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: env.emailFrom,
        to: [message.to],
        subject: message.subject,
        html: message.html,
        text: message.text,
      }),
    });
    if (!res.ok) {
      throw new Error(`Resend send failed: ${res.status} ${await res.text()}`);
    }
  }
}

let cached: EmailProvider | null = null;

export function getEmailProvider(): EmailProvider {
  if (cached) return cached;
  cached = env.emailProvider === "resend" ? new ResendEmailProvider() : new ConsoleEmailProvider();
  return cached;
}
