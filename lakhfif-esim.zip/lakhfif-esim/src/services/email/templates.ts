import { env } from "@/lib/env";
import { formatMoney, formatDataAmount } from "@/lib/utils";
import type { EmailMessage } from "./providers";

function layout(preheader: string, bodyHtml: string): string {
  return `<!doctype html>
<html>
  <body style="margin:0;padding:0;background:#F5F6FA;font-family:Helvetica,Arial,sans-serif;color:#14182B;">
    <span style="display:none;font-size:1px;color:#F5F6FA;">${preheader}</span>
    <table role="presentation" width="100%" style="padding:32px 0;">
      <tr><td align="center">
        <table role="presentation" width="480" style="background:#FFFFFF;border:1px solid #DFE2EC;border-radius:10px;overflow:hidden;">
          <tr><td style="background:#263873;padding:20px 28px;">
            <span style="color:#FFFFFF;font-size:18px;font-weight:700;">Lakhfif eSIM</span>
          </td></tr>
          <tr><td style="padding:28px;">${bodyHtml}</td></tr>
          <tr><td style="padding:20px 28px;border-top:1px solid #DFE2EC;color:#6B7089;font-size:13px;">
            Need help? Contact us at ${env.supportEmail}.
          </td></tr>
        </table>
      </td></tr>
    </table>
  </body>
</html>`;
}

function button(href: string, label: string): string {
  return `<a href="${href}" style="display:inline-block;background:#263873;color:#FFFFFF;text-decoration:none;padding:12px 20px;border-radius:8px;font-weight:600;margin-top:16px;">${label}</a>`;
}

export function orderReceivedEmail(params: {
  to: string;
  orderNumber: string;
  country: string;
  dataAmount: number;
  dataUnit: string;
  validityDays: number;
  amount: number;
  currency: string;
}): EmailMessage {
  const dataLabel = formatDataAmount(params.dataAmount, params.dataUnit);
  const price = formatMoney(params.amount, params.currency);
  const html = layout(
    `We've received order ${params.orderNumber}`,
    `<h1 style="font-size:20px;margin:0 0 12px;">Order received</h1>
     <p style="margin:0 0 16px;line-height:1.5;">Thanks — we've received order <strong>${params.orderNumber}</strong> for
     <strong>${dataLabel}</strong> in <strong>${params.country}</strong> (${params.validityDays} days), ${price}.</p>
     <p style="margin:0;line-height:1.5;">Your eSIM will be delivered digitally to this email as soon as payment is confirmed.</p>`
  );
  return {
    to: params.to,
    subject: `Order received — ${params.orderNumber}`,
    html,
    text: `Order received. ${params.orderNumber}: ${dataLabel} in ${params.country}, ${params.validityDays} days, ${price}. Your eSIM will be sent to this email once payment is confirmed.`,
  };
}

export function paymentSuccessfulEmail(params: {
  to: string;
  orderNumber: string;
  amount: number;
  currency: string;
}): EmailMessage {
  const price = formatMoney(params.amount, params.currency);
  const html = layout(
    `Payment confirmed for ${params.orderNumber}`,
    `<h1 style="font-size:20px;margin:0 0 12px;">Payment confirmed</h1>
     <p style="margin:0 0 16px;line-height:1.5;">We've confirmed your payment of <strong>${price}</strong> for order
     <strong>${params.orderNumber}</strong>. We're preparing your eSIM now — you'll get a separate email the moment it's ready, usually within a couple of minutes.</p>`
  );
  return {
    to: params.to,
    subject: `Payment confirmed — ${params.orderNumber}`,
    html,
    text: `Payment of ${price} confirmed for ${params.orderNumber}. We're preparing your eSIM now.`,
  };
}

export function esimReadyEmail(params: {
  to: string;
  orderNumber: string;
  country: string;
  dataAmount: number;
  dataUnit: string;
  validityDays: number;
  qrCodeDataUrl: string; // base64 PNG data URL
  manageUrl: string;
}): EmailMessage {
  const dataLabel = formatDataAmount(params.dataAmount, params.dataUnit);
  const html = layout(
    `Your eSIM for ${params.country} is ready`,
    `<h1 style="font-size:20px;margin:0 0 12px;">Your eSIM is ready</h1>
     <p style="margin:0 0 16px;line-height:1.5;">Order <strong>${params.orderNumber}</strong> — <strong>${dataLabel}</strong> in
     <strong>${params.country}</strong>, valid ${params.validityDays} days.</p>
     <p style="margin:0 0 12px;">Scan this QR code in your phone's eSIM settings to install it:</p>
     <img src="${params.qrCodeDataUrl}" width="180" height="180" alt="eSIM QR code" style="display:block;border:1px solid #DFE2EC;border-radius:8px;" />
     ${button(params.manageUrl, "View installation instructions")}`
  );
  return {
    to: params.to,
    subject: `Your eSIM for ${params.country} is ready — ${params.orderNumber}`,
    html,
    text: `Your eSIM for order ${params.orderNumber} (${dataLabel}, ${params.country}, ${params.validityDays} days) is ready. Open ${params.manageUrl} to view the QR code and install it.`,
  };
}

export function paymentFailedEmail(params: {
  to: string;
  orderNumber: string;
  retryUrl: string;
}): EmailMessage {
  const html = layout(
    `Payment didn't go through for ${params.orderNumber}`,
    `<h1 style="font-size:20px;margin:0 0 12px;">Payment didn't go through</h1>
     <p style="margin:0 0 16px;line-height:1.5;">We weren't able to confirm payment for order <strong>${params.orderNumber}</strong>. No eSIM has been issued and nothing further will be charged.</p>
     ${button(params.retryUrl, "Try again")}`
  );
  return {
    to: params.to,
    subject: `Payment didn't go through — ${params.orderNumber}`,
    html,
    text: `Payment for order ${params.orderNumber} didn't go through. No eSIM was issued. Try again: ${params.retryUrl}`,
  };
}

export function providerDelayEmail(params: {
  to: string;
  orderNumber: string;
}): EmailMessage {
  const html = layout(
    `A short delay preparing order ${params.orderNumber}`,
    `<h1 style="font-size:20px;margin:0 0 12px;">Your eSIM is taking a little longer</h1>
     <p style="margin:0 0 16px;line-height:1.5;">Your payment for order <strong>${params.orderNumber}</strong> was received successfully. We're having a short delay preparing your eSIM with our network partner — you'll receive it by email as soon as it's ready. You don't need to do anything.</p>`
  );
  return {
    to: params.to,
    subject: `A short delay preparing your eSIM — ${params.orderNumber}`,
    html,
    text: `Payment received for ${params.orderNumber}. Your eSIM is being prepared and will arrive by email shortly.`,
  };
}

export function passwordResetEmail(params: { to: string; resetUrl: string }): EmailMessage {
  const html = layout(
    "Reset your Lakhfif eSIM password",
    `<h1 style="font-size:20px;margin:0 0 12px;">Reset your password</h1>
     <p style="margin:0 0 16px;line-height:1.5;">We received a request to reset your password. This link expires in 1 hour and can only be used once. If you didn't request this, you can safely ignore this email.</p>
     ${button(params.resetUrl, "Reset password")}`
  );
  return {
    to: params.to,
    subject: "Reset your Lakhfif eSIM password",
    html,
    text: `Reset your password: ${params.resetUrl} (expires in 1 hour, one-time use). If you didn't request this, ignore this email.`,
  };
}

export function refundCompletedEmail(params: {
  to: string;
  orderNumber: string;
  amount: number;
  currency: string;
}): EmailMessage {
  const price = formatMoney(params.amount, params.currency);
  const html = layout(
    `Refund completed for ${params.orderNumber}`,
    `<h1 style="font-size:20px;margin:0 0 12px;">Refund completed</h1>
     <p style="margin:0 0 16px;line-height:1.5;">We've refunded <strong>${price}</strong> for order <strong>${params.orderNumber}</strong> to your original PayPal payment method. It may take a few days to appear.</p>`
  );
  return {
    to: params.to,
    subject: `Refund completed — ${params.orderNumber}`,
    html,
    text: `Refund of ${price} completed for order ${params.orderNumber}.`,
  };
}
