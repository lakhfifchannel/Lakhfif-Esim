import { env } from "@/lib/env";
import type { ESIMProvider } from "./provider.interface";
import { MockESIMProvider } from "./providers/mock-provider";
import { ExampleAggregatorProvider } from "./providers/example-aggregator-provider";

let cached: ESIMProvider | null = null;

/**
 * The only place in the app that decides which provider implementation is
 * live. Everything else (fulfillment.service.ts, the admin plan-sync
 * route, etc.) calls getESIMProvider() and only ever sees the ESIMProvider
 * interface — see ARCHITECTURE.md "Provider abstraction".
 *
 * Swap in a real aggregator by setting ESIM_PROVIDER_MODE=aggregator in
 * .env once you've filled in ExampleAggregatorProvider for the aggregator
 * you've chosen. No other file needs to change.
 */
export function getESIMProvider(): ESIMProvider {
  if (cached) return cached;

  if (env.esimProviderMode === "aggregator") {
    cached = new ExampleAggregatorProvider(env.esimProviderApiKey, env.esimProviderApiUrl);
  } else {
    cached = new MockESIMProvider();
  }
  return cached;
}
