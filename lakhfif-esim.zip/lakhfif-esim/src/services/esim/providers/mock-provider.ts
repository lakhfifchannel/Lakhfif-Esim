import type { ESIMProvider } from "../provider.interface";
import type {
  NormalizedPlan,
  ProviderESIMDetails,
  ProviderESIMStatus,
  ProviderOrderRequest,
  ProviderOrderResult,
  ProviderOrderResultItem,
  ProviderUsage,
} from "../types";
import { ProviderError } from "../types";

/**
 * Simulates a full eSIM aggregator so the entire checkout -> fulfillment ->
 * delivery flow can be built and tested with no real provider contract —
 * see spec section 21 / README "Running in mock mode".
 *
 * Test hooks (based on the plan's providerPlanId suffix):
 *   *-fail          createOrder returns FAILED for that item
 *   *-insufficient  createOrder returns INSUFFICIENT_BALANCE for that item
 *   *-delay         createOrder returns PENDING (order goes to
 *                   PROVIDER_PENDING). To simulate the provider's delayed
 *                   confirmation arriving later, POST the same shape a real
 *                   provider webhook would send to /api/webhooks/esim-provider
 *                   — see that route's comment for the exact payload.
 *   anything else   createOrder returns SUCCESS with fully populated,
 *                   deterministic eSIM fields.
 *
 * All "random" data below is a deterministic function of an id string, not
 * Math.random() or in-memory state — so getESIM/getUsage/getStatus keep
 * returning consistent answers across separate requests and server
 * restarts, the way a real provider's database-backed API would.
 */
export class MockESIMProvider implements ESIMProvider {
  async getPlans(): Promise<NormalizedPlan[]> {
    return MOCK_CATALOGUE;
  }

  async getPlan(providerPlanId: string): Promise<NormalizedPlan | null> {
    return MOCK_CATALOGUE.find((p) => p.providerPlanId === providerPlanId) ?? null;
  }

  async createOrder(order: ProviderOrderRequest): Promise<ProviderOrderResult> {
    const providerOrderId = `mock-order-${hashToHex(order.referenceId, 12)}`;

    const items: ProviderOrderResultItem[] = order.items.map((item) => {
      if (item.providerPlanId.endsWith("-fail")) {
        return {
          referenceId: item.referenceId,
          outcome: "FAILED",
          errorMessage: "Mock provider: simulated rejection (plan id ends in -fail).",
        };
      }
      if (item.providerPlanId.endsWith("-insufficient")) {
        return {
          referenceId: item.referenceId,
          outcome: "INSUFFICIENT_BALANCE",
          errorMessage: "Mock provider: simulated insufficient wallet balance.",
        };
      }
      if (item.providerPlanId.endsWith("-delay")) {
        return { referenceId: item.referenceId, outcome: "PENDING" };
      }

      const plan = MOCK_CATALOGUE.find((p) => p.providerPlanId === item.providerPlanId);
      const seed = `${item.referenceId}:${item.providerPlanId}`;
      const esim = generateEsimFields(seed, plan?.validityDays ?? 7);
      return {
        referenceId: item.referenceId,
        outcome: "SUCCESS",
        ...esim,
      };
    });

    return { providerOrderId, items, raw: { mock: true, request: order } };
  }

  async getOrder(providerOrderId: string): Promise<ProviderOrderResult> {
    if (!providerOrderId.startsWith("mock-order-")) {
      throw new ProviderError("Unknown mock order id", "NOT_FOUND");
    }
    // The mock doesn't persist order history; callers that need the result
    // of a specific createOrder() call should use the value it returned.
    // This exists to satisfy the interface for status-refresh flows.
    return { providerOrderId, items: [], raw: { mock: true } };
  }

  async getESIM(providerEsimId: string): Promise<ProviderESIMDetails> {
    const esim = generateEsimFields(providerEsimId, 30);
    return { providerEsimId, ...esim };
  }

  async getUsage(providerEsimId: string): Promise<ProviderUsage> {
    const totalMb = 1024 * (1 + (hashToInt(providerEsimId) % 5)); // 1-5GB plan
    const usedMb = Math.round(totalMb * (0.1 + (hashToInt(providerEsimId + ":u") % 60) / 100));
    return { dataUsedMb: usedMb, dataRemainingMb: Math.max(totalMb - usedMb, 0) };
  }

  async getStatus(_providerEsimId: string): Promise<ProviderESIMStatus> {
    return "ACTIVE";
  }
}

// ---------------------------------------------------------------- utils --

function hashToInt(input: string): number {
  let hash = 5381;
  for (let i = 0; i < input.length; i++) {
    hash = (hash * 33) ^ input.charCodeAt(i);
  }
  return Math.abs(hash);
}

function hashToHex(input: string, length: number): string {
  let out = "";
  let seed = hashToInt(input);
  while (out.length < length) {
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    out += seed.toString(16);
  }
  return out.slice(0, length);
}

function generateEsimFields(seed: string, validityDays: number) {
  const iccid = `8944${Array.from({ length: 15 }, (_, i) =>
    (hashToInt(seed + i) % 10).toString()
  ).join("")}`;
  const smDpAddress = "rsp.mock-lakhfif.example";
  const activationCode = hashToHex(seed + ":activation", 16).toUpperCase();
  const lpaString = `LPA:1$${smDpAddress}$${activationCode}`;
  const expiryDate = new Date(Date.now() + validityDays * 24 * 60 * 60 * 1000).toISOString();

  return {
    providerEsimId: `mock-esim-${hashToHex(seed, 10)}`,
    iccid,
    qrCodeData: lpaString,
    lpaString,
    smDpAddress,
    activationCode,
    expiryDate,
  };
}

// ------------------------------------------------------------ catalogue --
// Mirrors the homepage's "popular destinations" list. Two tiers per
// country keeps this readable; add more freely, the shape is what matters.

interface CountrySeed {
  country: string;
  countryCode: string;
  region: string;
  wholesaleSmall: number; // cents, 1GB / 7 days
  wholesaleMedium: number; // cents, 5GB / 30 days
}

const COUNTRY_SEEDS: CountrySeed[] = [
  { country: "United States", countryCode: "US", region: "Americas", wholesaleSmall: 320, wholesaleMedium: 950 },
  { country: "United Kingdom", countryCode: "GB", region: "Europe", wholesaleSmall: 280, wholesaleMedium: 820 },
  { country: "France", countryCode: "FR", region: "Europe", wholesaleSmall: 270, wholesaleMedium: 800 },
  { country: "Spain", countryCode: "ES", region: "Europe", wholesaleSmall: 260, wholesaleMedium: 780 },
  { country: "Italy", countryCode: "IT", region: "Europe", wholesaleSmall: 270, wholesaleMedium: 800 },
  { country: "Turkey", countryCode: "TR", region: "Europe", wholesaleSmall: 220, wholesaleMedium: 650 },
  { country: "United Arab Emirates", countryCode: "AE", region: "Middle East", wholesaleSmall: 340, wholesaleMedium: 990 },
  { country: "Morocco", countryCode: "MA", region: "Africa", wholesaleSmall: 240, wholesaleMedium: 700 },
  { country: "Japan", countryCode: "JP", region: "Asia", wholesaleSmall: 300, wholesaleMedium: 890 },
  { country: "Thailand", countryCode: "TH", region: "Asia", wholesaleSmall: 230, wholesaleMedium: 690 },
];

function buildCatalogue(): NormalizedPlan[] {
  const plans: NormalizedPlan[] = [];
  for (const seed of COUNTRY_SEEDS) {
    const base = seed.countryCode.toLowerCase();
    plans.push({
      id: `mock-${base}-1gb-7d`,
      provider: "mock",
      providerPlanId: `mock-${base}-1gb-7d`,
      country: seed.country,
      countryCode: seed.countryCode,
      region: seed.region,
      coverage: [seed.countryCode],
      dataAmount: 1,
      dataUnit: "GB",
      validityDays: 7,
      wholesalePrice: seed.wholesaleSmall,
      retailPrice: Math.round(seed.wholesaleSmall * 1.3),
      currency: "USD",
      network: "Partner LTE/5G network",
      activationType: "FIRST_USE",
      supportedDevices: ["iPhone XS or later", "Google Pixel 3 or later", "Samsung Galaxy S20 or later"],
      fairUsagePolicy: null,
      planType: "DATA_ONLY",
    });
    plans.push({
      id: `mock-${base}-5gb-30d`,
      provider: "mock",
      providerPlanId: `mock-${base}-5gb-30d`,
      country: seed.country,
      countryCode: seed.countryCode,
      region: seed.region,
      coverage: [seed.countryCode],
      dataAmount: 5,
      dataUnit: "GB",
      validityDays: 30,
      wholesalePrice: seed.wholesaleMedium,
      retailPrice: Math.round(seed.wholesaleMedium * 1.3),
      currency: "USD",
      network: "Partner LTE/5G network",
      activationType: "FIRST_USE",
      supportedDevices: ["iPhone XS or later", "Google Pixel 3 or later", "Samsung Galaxy S20 or later"],
      fairUsagePolicy: null,
      planType: "DATA_ONLY",
    });
  }
  return plans;
}

export const MOCK_CATALOGUE = buildCatalogue();
