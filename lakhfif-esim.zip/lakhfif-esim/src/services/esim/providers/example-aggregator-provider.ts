import type { ESIMProvider } from "../provider.interface";
import type {
  NormalizedPlan,
  ProviderESIMDetails,
  ProviderESIMStatus,
  ProviderOrderRequest,
  ProviderOrderResult,
  ProviderUsage,
} from "../types";
import { ProviderError } from "../types";

/**
 * TEMPLATE, not a working integration. The endpoint paths, field names and
 * error shapes below are illustrative placeholders — every real eSIM
 * aggregator (Airalo Partner API, eSIM Access, Maya Mobile, etc.) has its
 * own actual contract, and I don't have that contract's specifics, so I'm
 * not going to guess at real endpoint behavior and have you find out it's
 * wrong in production.
 *
 * What IS real and worth keeping: the shape of the class (implements the
 * same ESIMProvider interface as the mock), the auth-header pattern, the
 * response -> NormalizedPlan mapping step, and the error handling pattern.
 * Once you pick a real aggregator:
 *   1. Replace BASE_PATH and every fetch call below with that provider's
 *      actual documented endpoints.
 *   2. Replace the `Raw*` interfaces with that provider's real response
 *      shape (generate them from their API docs/OpenAPI spec if they have
 *      one) and adjust the map* functions accordingly.
 *   3. Set ESIM_PROVIDER_MODE=aggregator and fill in ESIM_PROVIDER_API_KEY
 *      / ESIM_PROVIDER_API_URL in .env.
 *   4. Add a matching row to the Provider table (see prisma/seed.ts) with
 *      the correct BillingMode for that provider's account type.
 */
export class ExampleAggregatorProvider implements ESIMProvider {
  constructor(
    private readonly apiKey: string,
    private readonly baseUrl: string
  ) {}

  private async request<T>(path: string, init?: RequestInit): Promise<T> {
    const res = await fetch(`${this.baseUrl}${path}`, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        // Placeholder auth scheme — replace with the real provider's.
        Authorization: `Bearer ${this.apiKey}`,
        ...(init?.headers ?? {}),
      },
    });

    if (res.status === 401 || res.status === 403) {
      throw new ProviderError("Provider authentication failed", "AUTH_FAILED");
    }
    if (res.status === 429) {
      throw new ProviderError("Provider rate limit exceeded", "RATE_LIMITED");
    }
    if (res.status === 404) {
      throw new ProviderError("Provider resource not found", "NOT_FOUND");
    }
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new ProviderError(
        `Provider request failed (${res.status})`,
        "UPSTREAM_ERROR",
        body
      );
    }
    return res.json() as Promise<T>;
  }

  async getPlans(): Promise<NormalizedPlan[]> {
    const data = await this.request<{ plans: RawPlan[] }>("/v1/plans");
    return data.plans.map(mapPlan);
  }

  async getPlan(providerPlanId: string): Promise<NormalizedPlan | null> {
    try {
      const plan = await this.request<RawPlan>(`/v1/plans/${providerPlanId}`);
      return mapPlan(plan);
    } catch (err) {
      if (err instanceof ProviderError && err.code === "NOT_FOUND") return null;
      throw err;
    }
  }

  async createOrder(order: ProviderOrderRequest): Promise<ProviderOrderResult> {
    // IMPORTANT: if this provider supports a client-supplied idempotency
    // key, pass order.referenceId as one. That, plus fulfillment.service.ts
    // never calling this twice for an already-PROVIDER_PROCESSING order, is
    // what stops a retried request from creating a duplicate purchase.
    const raw = await this.request<RawOrderResult>("/v1/orders", {
      method: "POST",
      headers: { "Idempotency-Key": order.referenceId },
      body: JSON.stringify({
        reference_id: order.referenceId,
        items: order.items.map((i) => ({
          plan_id: i.providerPlanId,
          quantity: i.quantity,
          reference_id: i.referenceId,
        })),
      }),
    });
    return mapOrderResult(raw);
  }

  async getOrder(providerOrderId: string): Promise<ProviderOrderResult> {
    const raw = await this.request<RawOrderResult>(`/v1/orders/${providerOrderId}`);
    return mapOrderResult(raw);
  }

  async getESIM(providerEsimId: string): Promise<ProviderESIMDetails> {
    const raw = await this.request<RawEsim>(`/v1/esims/${providerEsimId}`);
    return mapEsim(raw);
  }

  async getUsage(providerEsimId: string): Promise<ProviderUsage> {
    const raw = await this.request<{ used_mb: number; remaining_mb: number | null }>(
      `/v1/esims/${providerEsimId}/usage`
    );
    return { dataUsedMb: raw.used_mb, dataRemainingMb: raw.remaining_mb };
  }

  async getStatus(providerEsimId: string): Promise<ProviderESIMStatus> {
    const raw = await this.request<{ status: string }>(`/v1/esims/${providerEsimId}/status`);
    return mapStatus(raw.status);
  }
}

// ---- placeholder upstream shapes + mappers -----------------------------
// Replace all of this with the real provider's actual response shape.

interface RawPlan {
  id: string;
  country_name: string;
  country_code: string;
  region: string | null;
  coverage_countries: string[] | null;
  data_amount_mb: number | null; // null/omitted commonly means unlimited
  validity_days: number;
  wholesale_price_cents: number;
  suggested_retail_price_cents: number | null;
  currency: string;
  network_name: string | null;
  activation_type: string | null;
  supported_devices: string[] | null;
  fair_usage_policy: string | null;
  plan_type: string | null;
}

function mapPlan(raw: RawPlan): NormalizedPlan {
  const unlimited = raw.data_amount_mb == null;
  return {
    id: raw.id,
    provider: "example_aggregator",
    providerPlanId: raw.id,
    country: raw.country_name,
    countryCode: raw.country_code,
    region: raw.region,
    coverage: raw.coverage_countries ?? [raw.country_code],
    dataAmount: unlimited ? 0 : (raw.data_amount_mb as number) / 1024,
    dataUnit: unlimited ? "UNLIMITED" : "GB",
    validityDays: raw.validity_days,
    wholesalePrice: raw.wholesale_price_cents,
    retailPrice: raw.suggested_retail_price_cents ?? raw.wholesale_price_cents,
    currency: raw.currency,
    network: raw.network_name,
    activationType: raw.activation_type,
    supportedDevices: raw.supported_devices ?? [],
    fairUsagePolicy: raw.fair_usage_policy,
    planType: raw.plan_type,
  };
}

interface RawOrderResultItem {
  reference_id: string;
  status: "success" | "failed" | "insufficient_balance" | "pending";
  esim_id?: string;
  iccid?: string;
  qr_code_data?: string;
  lpa_string?: string;
  smdp_address?: string;
  activation_code?: string;
  expires_at?: string;
  error_message?: string;
}

interface RawOrderResult {
  order_id: string;
  items: RawOrderResultItem[];
}

function mapOrderResult(raw: RawOrderResult): ProviderOrderResult {
  const outcomeMap: Record<RawOrderResultItem["status"], ProviderOrderResult["items"][number]["outcome"]> = {
    success: "SUCCESS",
    failed: "FAILED",
    insufficient_balance: "INSUFFICIENT_BALANCE",
    pending: "PENDING",
  };
  return {
    providerOrderId: raw.order_id,
    raw,
    items: raw.items.map((item) => ({
      referenceId: item.reference_id,
      outcome: outcomeMap[item.status],
      providerEsimId: item.esim_id,
      iccid: item.iccid,
      qrCodeData: item.qr_code_data,
      lpaString: item.lpa_string,
      smDpAddress: item.smdp_address,
      activationCode: item.activation_code,
      expiryDate: item.expires_at,
      errorMessage: item.error_message,
    })),
  };
}

interface RawEsim {
  esim_id: string;
  iccid?: string;
  qr_code_data?: string;
  lpa_string?: string;
  smdp_address?: string;
  activation_code?: string;
  expires_at?: string;
}

function mapEsim(raw: RawEsim): ProviderESIMDetails {
  return {
    providerEsimId: raw.esim_id,
    iccid: raw.iccid,
    qrCodeData: raw.qr_code_data,
    lpaString: raw.lpa_string,
    smDpAddress: raw.smdp_address,
    activationCode: raw.activation_code,
    expiryDate: raw.expires_at,
  };
}

function mapStatus(raw: string): ProviderESIMStatus {
  const known: ProviderESIMStatus[] = ["PENDING", "ACTIVE", "INACTIVE", "EXPIRED", "FAILED"];
  const upper = raw.toUpperCase() as ProviderESIMStatus;
  return known.includes(upper) ? upper : "PENDING";
}
