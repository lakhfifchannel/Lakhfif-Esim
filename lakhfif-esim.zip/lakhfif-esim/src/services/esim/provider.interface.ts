import type {
  NormalizedPlan,
  ProviderESIMDetails,
  ProviderESIMStatus,
  ProviderOrderRequest,
  ProviderOrderResult,
  ProviderUsage,
} from "./types";

/**
 * Every eSIM aggregator/carrier integration implements this. Nothing else
 * in the app — pricing, order fulfillment, the API routes — talks to a
 * provider except through this interface, so swapping or adding an
 * aggregator never touches order/pricing/webhook logic. See
 * providers/mock-provider.ts for a full reference implementation and
 * providers/example-aggregator-provider.ts for the template to fill in
 * once you've picked a real aggregator.
 */
export interface ESIMProvider {
  /** Full current catalogue, already mapped to NormalizedPlan. Called by
   * the plan-sync job (or on demand in dev) — not on every page load. */
  getPlans(): Promise<NormalizedPlan[]>;

  getPlan(providerPlanId: string): Promise<NormalizedPlan | null>;

  /** Purchase/provision. Only ever called after payment is confirmed —
   * see fulfillment.service.ts. Must be safe to retry with the same
   * referenceId without creating a duplicate purchase; the mock and
   * example adapters show the pattern (echo referenceId, check for an
   * existing provider order before creating a new one where the
   * upstream API supports that). */
  createOrder(order: ProviderOrderRequest): Promise<ProviderOrderResult>;

  getOrder(providerOrderId: string): Promise<ProviderOrderResult>;

  getESIM(providerEsimId: string): Promise<ProviderESIMDetails>;

  getUsage(providerEsimId: string): Promise<ProviderUsage>;

  getStatus(providerEsimId: string): Promise<ProviderESIMStatus>;
}
