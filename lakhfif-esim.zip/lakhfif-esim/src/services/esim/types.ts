// The normalized shape every provider adapter must map its upstream
// response into. Nothing downstream (pricing, orders, the frontend) ever
// sees a provider's native response shape — only this. That's what lets a
// second or replacement aggregator be added by writing one new adapter
// file, per ARCHITECTURE.md.

export interface NormalizedPlan {
  /** Provider-native plan id (== providerPlanId below); duplicated here so
   * a plan fetched fresh from the provider is self-describing. */
  id: string;
  provider: string; // Provider.code
  providerPlanId: string;

  country: string | null; // display name, e.g. "United States"
  countryCode: string | null; // ISO 3166-1 alpha-2
  region: string | null;
  coverage: string[]; // ISO country codes for multi-country plans

  dataAmount: number;
  dataUnit: "MB" | "GB" | "UNLIMITED";
  validityDays: number;

  /** Minor units (cents). What the provider charges you. */
  wholesalePrice: number;
  /** Minor units. Provider's own suggested retail, if it sends one — your
   * pricing service is free to ignore this and apply your own markup. */
  retailPrice: number;
  currency: string;

  network: string | null;
  activationType: string | null;
  supportedDevices: string[];
  fairUsagePolicy: string | null;
  planType: string | null;
}

export interface ProviderOrderRequestItem {
  providerPlanId: string;
  quantity: number;
  /** Your internal OrderItem.id, passed through so the provider's
   * response (or its later webhook) can be matched back to it. */
  referenceId: string;
}

export interface ProviderOrderRequest {
  /** Your internal Order.orderNumber, for the provider's own reconciliation
   * and support conversations — never expose provider identity or this
   * reference back to the customer. */
  referenceId: string;
  items: ProviderOrderRequestItem[];
}

export type ProviderOrderOutcome =
  | "SUCCESS"
  | "FAILED"
  | "INSUFFICIENT_BALANCE"
  | "PENDING";

export interface ProviderOrderResultItem {
  referenceId: string; // echoes ProviderOrderRequestItem.referenceId
  outcome: ProviderOrderOutcome;
  providerEsimId?: string;
  iccid?: string;
  qrCodeData?: string; // raw LPA string to encode as a QR
  lpaString?: string;
  smDpAddress?: string;
  activationCode?: string;
  expiryDate?: string; // ISO date
  errorMessage?: string;
}

export interface ProviderOrderResult {
  providerOrderId: string;
  items: ProviderOrderResultItem[];
  raw: unknown; // stored as-is in ProviderTransaction.rawResponse for audit
}

export interface ProviderESIMDetails {
  providerEsimId: string;
  iccid?: string;
  qrCodeData?: string;
  lpaString?: string;
  smDpAddress?: string;
  activationCode?: string;
  expiryDate?: string;
}

export interface ProviderUsage {
  dataUsedMb: number;
  dataRemainingMb: number | null; // null when the provider reports unlimited
}

export type ProviderESIMStatus =
  | "PENDING"
  | "ACTIVE"
  | "INACTIVE"
  | "EXPIRED"
  | "FAILED";

export class ProviderError extends Error {
  constructor(
    message: string,
    public readonly code:
      | "AUTH_FAILED"
      | "INSUFFICIENT_BALANCE"
      | "NOT_FOUND"
      | "RATE_LIMITED"
      | "UPSTREAM_ERROR"
      | "VALIDATION_ERROR",
    public readonly raw?: unknown
  ) {
    super(message);
    this.name = "ProviderError";
  }
}
