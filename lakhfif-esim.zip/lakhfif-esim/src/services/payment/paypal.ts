import "server-only";
import { env, PAYPAL_API_BASE } from "@/lib/env";

// Direct REST calls to PayPal's /v2/checkout/orders API rather than an SDK
// package, so this doesn't depend on any particular SDK's version churn —
// PayPal's REST contract itself has been stable for years. See
// https://developer.paypal.com/docs/api/orders/v2/ and
// https://developer.paypal.com/docs/api/webhooks/v1/#verify-webhook-signature

let cachedToken: { value: string; expiresAt: number } | null = null;

async function getAccessToken(): Promise<string> {
  if (cachedToken && cachedToken.expiresAt > Date.now() + 30_000) {
    return cachedToken.value;
  }
  const basicAuth = Buffer.from(
    `${env.paypalClientId}:${env.paypalClientSecret}`
  ).toString("base64");

  const res = await fetch(`${PAYPAL_API_BASE}/v1/oauth2/token`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${basicAuth}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials",
    cache: "no-store",
  });
  if (!res.ok) {
    throw new Error(`PayPal auth failed: ${res.status} ${await res.text()}`);
  }
  const data = (await res.json()) as { access_token: string; expires_in: number };
  cachedToken = { value: data.access_token, expiresAt: Date.now() + data.expires_in * 1000 };
  return data.access_token;
}

async function paypalFetch<T>(path: string, init: RequestInit = {}): Promise<T> {
  const token = await getAccessToken();
  const res = await fetch(`${PAYPAL_API_BASE}${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      ...(init.headers ?? {}),
    },
    cache: "no-store",
  });
  const body = await res.json().catch(() => null);
  if (!res.ok) {
    throw new Error(
      `PayPal API error on ${path}: ${res.status} ${JSON.stringify(body)}`
    );
  }
  return body as T;
}

export interface CreatePayPalOrderResult {
  paypalOrderId: string;
  approveUrl: string | null;
  raw: unknown;
}

/** Creates a PayPal order for the amount already locked in by the pricing
 * service. `referenceId` should be the internal Order.orderNumber so it
 * shows up in the PayPal dashboard for reconciliation. */
export async function createPayPalOrder(
  amountMinorUnits: number,
  currency: string,
  referenceId: string
): Promise<CreatePayPalOrderResult> {
  const raw = await paypalFetch<{
    id: string;
    links: { rel: string; href: string }[];
  }>("/v2/checkout/orders", {
    method: "POST",
    headers: { "PayPal-Request-Id": `create-${referenceId}` },
    body: JSON.stringify({
      intent: "CAPTURE",
      purchase_units: [
        {
          reference_id: referenceId,
          custom_id: referenceId, // echoed back on the Capture resource in webhooks — see /api/webhooks/paypal
          amount: {
            currency_code: currency,
            value: (amountMinorUnits / 100).toFixed(2),
          },
        },
      ],
      application_context: {
        brand_name: "Lakhfif eSIM",
        shipping_preference: "NO_SHIPPING", // digital delivery only
        user_action: "PAY_NOW",
      },
    }),
  });

  const approveUrl = raw.links.find((l) => l.rel === "approve")?.href ?? null;
  return { paypalOrderId: raw.id, approveUrl, raw };
}

export interface CapturePayPalOrderResult {
  status: string; // "COMPLETED" | "DECLINED" | ...
  captureId: string | null;
  payerEmail: string | null;
  raw: unknown;
}

/** Server-to-server capture. Idempotency key ties this to the internal
 * order so a network retry on our side can't create a second capture. */
export async function capturePayPalOrder(
  paypalOrderId: string,
  idempotencyKey: string
): Promise<CapturePayPalOrderResult> {
  const raw = await paypalFetch<{
    status: string;
    payer?: { email_address?: string };
    purchase_units?: {
      payments?: { captures?: { id: string; status: string }[] };
    }[];
  }>(`/v2/checkout/orders/${paypalOrderId}/capture`, {
    method: "POST",
    headers: { "PayPal-Request-Id": `capture-${idempotencyKey}` },
    body: JSON.stringify({}),
  });

  const capture = raw.purchase_units?.[0]?.payments?.captures?.[0];
  return {
    status: raw.status,
    captureId: capture?.id ?? null,
    payerEmail: raw.payer?.email_address ?? null,
    raw,
  };
}

export interface RefundPayPalCaptureResult {
  refundId: string;
  status: string;
  raw: unknown;
}

/** Full refund of a capture by default — pass amount+currency for a
 * partial refund. PayPal only needs the capture id, not the original
 * order id. */
export async function refundPayPalCapture(
  captureId: string,
  idempotencyKey: string,
  partial?: { amount: number; currency: string }
): Promise<RefundPayPalCaptureResult> {
  const raw = await paypalFetch<{ id: string; status: string }>(
    `/v2/payments/captures/${captureId}/refund`,
    {
      method: "POST",
      headers: { "PayPal-Request-Id": `refund-${idempotencyKey}` },
      body: JSON.stringify(
        partial
          ? { amount: { value: (partial.amount / 100).toFixed(2), currency_code: partial.currency } }
          : {}
      ),
    }
  );
  return { refundId: raw.id, status: raw.status, raw };
}

export interface PayPalWebhookHeaders {
  authAlgo: string;
  certUrl: string;
  transmissionId: string;
  transmissionSig: string;
  transmissionTime: string;
}

/** Asks PayPal's own API whether a webhook payload's signature is
 * genuine, rather than re-implementing the crypto locally. This is
 * PayPal's own documented, recommended verification method. Never treat a
 * webhook as authentic without this coming back "SUCCESS". */
export async function verifyPayPalWebhookSignature(
  headers: PayPalWebhookHeaders,
  webhookEvent: unknown
): Promise<boolean> {
  const result = await paypalFetch<{ verification_status: string }>(
    "/v1/notifications/verify-webhook-signature",
    {
      method: "POST",
      body: JSON.stringify({
        auth_algo: headers.authAlgo,
        cert_url: headers.certUrl,
        transmission_id: headers.transmissionId,
        transmission_sig: headers.transmissionSig,
        transmission_time: headers.transmissionTime,
        webhook_id: env.paypalWebhookId,
        webhook_event: webhookEvent,
      }),
    }
  );
  return result.verification_status === "SUCCESS";
}
