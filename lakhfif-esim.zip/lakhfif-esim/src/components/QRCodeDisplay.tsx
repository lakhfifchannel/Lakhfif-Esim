"use client";

import { useState } from "react";

export function QRCodeDisplay(props: {
  qrCodeDataUrl: string;
  smDpAddress: string | null;
  activationCode: string | null;
  iccid: string | null;
}) {
  const [copied, setCopied] = useState<string | null>(null);

  async function copy(label: string, value: string) {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(label);
      setTimeout(() => setCopied(null), 1800);
    } catch {
      // Clipboard API can be unavailable (e.g. insecure context) — the
      // value is still visible on screen to copy manually.
    }
  }

  const fields: { label: string; value: string | null }[] = [
    { label: "SM-DP+ address", value: props.smDpAddress },
    { label: "Activation code", value: props.activationCode },
    { label: "ICCID", value: props.iccid },
  ];

  return (
    <div className="rounded-card border border-line bg-white p-6">
      <img
        src={props.qrCodeDataUrl}
        alt="eSIM activation QR code"
        width={220}
        height={220}
        className="mx-auto rounded-lg border border-line"
      />
      <p className="mt-4 text-center text-sm text-muted">
        Open Settings → Cellular/Mobile → Add eSIM and scan this code.
      </p>

      <dl className="mt-6 space-y-3 border-t border-line pt-5">
        {fields.map(
          (field) =>
            field.value && (
              <div key={field.label} className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <dt className="text-xs text-muted">{field.label}</dt>
                  <dd className="truncate text-sm text-ink">{field.value}</dd>
                </div>
                <button
                  type="button"
                  onClick={() => copy(field.label, field.value as string)}
                  className="shrink-0 rounded-full border border-line px-3 py-1 text-xs font-medium text-ink hover:border-horizon hover:text-horizon"
                >
                  {copied === field.label ? "Copied" : "Copy"}
                </button>
              </div>
            )
        )}
      </dl>
    </div>
  );
}
