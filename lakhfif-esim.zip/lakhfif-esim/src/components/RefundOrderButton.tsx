"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export function RefundOrderButton({ orderId, currency }: { orderId: string; currency: string }) {
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState(""); // major units, e.g. "5.00"; blank = full refund
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  async function refund() {
    const isFull = amount.trim() === "";
    if (!confirm(isFull ? "Refund this order's full payment via PayPal? This cannot be undone." : `Refund ${amount} ${currency} via PayPal? This cannot be undone.`)) {
      return;
    }
    setLoading(true);
    setError(null);
    const res = await fetch(`/api/admin/orders/${orderId}/refund`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(isFull ? {} : { amount: Math.round(Number(amount) * 100) }),
    });
    const data = await res.json().catch(() => null);
    setLoading(false);
    if (!res.ok) {
      setError(data?.error ?? "Refund failed");
      return;
    }
    setOpen(false);
    router.refresh();
  }

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="rounded-full border border-line px-3 py-1 text-xs font-medium text-danger hover:border-danger"
      >
        Refund
      </button>
    );
  }

  return (
    <div className="inline-flex flex-col items-end gap-1">
      <div className="flex items-center gap-1">
        <input
          type="number"
          step="0.01"
          min="0"
          placeholder="Full amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          className="w-24 rounded-lg border border-line px-2 py-1 text-xs text-ink"
        />
        <button
          type="button"
          onClick={refund}
          disabled={loading}
          className="rounded-full bg-danger px-3 py-1 text-xs font-medium text-white disabled:opacity-60"
        >
          {loading ? "…" : "Confirm"}
        </button>
        <button type="button" onClick={() => setOpen(false)} className="text-xs text-muted hover:text-ink">
          Cancel
        </button>
      </div>
      {error && <span className="text-xs text-danger">{error}</span>}
    </div>
  );
}
