"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export function RetryOrderButton({ orderId }: { orderId: string }) {
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function retry() {
    setLoading(true);
    await fetch(`/api/admin/orders/${orderId}/retry`, { method: "POST" });
    setLoading(false);
    router.refresh();
  }

  return (
    <button
      type="button"
      onClick={retry}
      disabled={loading}
      className="rounded-full border border-line px-3 py-1 text-xs font-medium text-ink hover:border-horizon hover:text-horizon disabled:opacity-60"
    >
      {loading ? "Retrying…" : "Retry fulfillment"}
    </button>
  );
}
