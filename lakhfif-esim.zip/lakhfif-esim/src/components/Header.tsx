import Link from "next/link";
import { getCustomerSession } from "@/lib/auth";

export async function Header() {
  const session = await getCustomerSession();

  return (
    <header className="border-b border-line bg-paper">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
        <Link href="/" className="font-display text-lg font-bold tracking-tight text-ink">
          Lakhfif <span className="text-horizon">eSIM</span>
        </Link>

        <nav className="hidden items-center gap-6 text-sm font-medium text-ink md:flex">
          <Link href="/plans" className="hover:text-horizon">
            Plans
          </Link>
          {session && (
            <>
              <Link href="/account/esims" className="hover:text-horizon">
                My eSIMs
              </Link>
              <Link href="/account/orders" className="hover:text-horizon">
                My orders
              </Link>
            </>
          )}
        </nav>

        {session ? (
          <form action="/api/auth/logout" method="post" className="flex items-center gap-3">
            <span className="hidden text-sm text-muted sm:inline">{session.email}</span>
            <button
              type="submit"
              className="rounded-full border border-line px-4 py-1.5 text-sm font-medium text-ink hover:border-horizon hover:text-horizon"
            >
              Log out
            </button>
          </form>
        ) : (
          <div className="flex items-center gap-3">
            <Link href="/login" className="text-sm font-medium text-ink hover:text-horizon">
              Log in
            </Link>
            <Link
              href="/register"
              className="rounded-full bg-horizon px-4 py-1.5 text-sm font-medium text-white hover:bg-horizon-dark"
            >
              Sign up
            </Link>
          </div>
        )}
      </div>
    </header>
  );
}
