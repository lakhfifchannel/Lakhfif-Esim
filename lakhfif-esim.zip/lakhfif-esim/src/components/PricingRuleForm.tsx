"use client";

import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";

type Scope = "GLOBAL" | "REGION" | "COUNTRY" | "PROVIDER" | "DATA_AMOUNT" | "PLAN";

export function PricingRuleForm(props: {
  countries: { id: string; name: string }[];
  regions: { id: string; name: string }[];
  providers: { id: string; name: string }[];
  plans: { id: string; label: string }[];
}) {
  const router = useRouter();
  const [scope, setScope] = useState<Scope>("GLOBAL");
  const [scopeRefId, setScopeRefId] = useState("");
  const [dataMin, setDataMin] = useState("");
  const [dataMax, setDataMax] = useState("");
  const [markupType, setMarkupType] = useState<"PERCENTAGE" | "FIXED">("PERCENTAGE");
  const [markupValue, setMarkupValue] = useState("40");
  const [priority, setPriority] = useState("0");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const targetOptions =
    scope === "COUNTRY" ? props.countries : scope === "REGION" ? props.regions : scope === "PROVIDER" ? props.providers : [];

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const res = await fetch("/api/admin/pricing-rules", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        scope,
        scopeRefId: scopeRefId || undefined,
        dataAmountMin: dataMin ? Number(dataMin) : undefined,
        dataAmountMax: dataMax ? Number(dataMax) : undefined,
        markupType,
        markupValue: Number(markupValue),
        priority: Number(priority) || 0,
      }),
    });
    const data = await res.json().catch(() => null);
    setLoading(false);

    if (!res.ok) {
      setError(data?.error ?? "Something went wrong");
      return;
    }
    setScopeRefId("");
    router.refresh();
  }

  return (
    <form onSubmit={onSubmit} className="grid grid-cols-2 gap-3 rounded-card border border-line bg-white p-5 sm:grid-cols-6">
      <label className="col-span-2 block sm:col-span-1">
        <span className="text-xs font-medium text-muted">Scope</span>
        <select
          value={scope}
          onChange={(e) => {
            setScope(e.target.value as Scope);
            setScopeRefId("");
          }}
          className="mt-1 w-full rounded-lg border border-line px-2 py-2 text-sm text-ink"
        >
          <option value="GLOBAL">Global</option>
          <option value="COUNTRY">Country</option>
          <option value="REGION">Region</option>
          <option value="PROVIDER">Provider</option>
          <option value="DATA_AMOUNT">Data amount</option>
          <option value="PLAN">Specific plan</option>
        </select>
      </label>

      {(scope === "COUNTRY" || scope === "REGION" || scope === "PROVIDER") && (
        <label className="col-span-2 block sm:col-span-2">
          <span className="text-xs font-medium text-muted">Target</span>
          <select
            required
            value={scopeRefId}
            onChange={(e) => setScopeRefId(e.target.value)}
            className="mt-1 w-full rounded-lg border border-line px-2 py-2 text-sm text-ink"
          >
            <option value="">Select…</option>
            {targetOptions.map((o) => (
              <option key={o.id} value={o.id}>
                {o.name}
              </option>
            ))}
          </select>
        </label>
      )}

      {scope === "PLAN" && (
        <label className="col-span-2 block sm:col-span-2">
          <span className="text-xs font-medium text-muted">Plan</span>
          <select
            required
            value={scopeRefId}
            onChange={(e) => setScopeRefId(e.target.value)}
            className="mt-1 w-full rounded-lg border border-line px-2 py-2 text-sm text-ink"
          >
            <option value="">Select…</option>
            {props.plans.map((p) => (
              <option key={p.id} value={p.id}>
                {p.label}
              </option>
            ))}
          </select>
        </label>
      )}

      {scope === "DATA_AMOUNT" && (
        <>
          <label className="block">
            <span className="text-xs font-medium text-muted">Min GB</span>
            <input
              type="number"
              step="0.1"
              value={dataMin}
              onChange={(e) => setDataMin(e.target.value)}
              className="mt-1 w-full rounded-lg border border-line px-2 py-2 text-sm text-ink"
            />
          </label>
          <label className="block">
            <span className="text-xs font-medium text-muted">Max GB</span>
            <input
              type="number"
              step="0.1"
              value={dataMax}
              onChange={(e) => setDataMax(e.target.value)}
              className="mt-1 w-full rounded-lg border border-line px-2 py-2 text-sm text-ink"
            />
          </label>
        </>
      )}

      <label className="block">
        <span className="text-xs font-medium text-muted">Markup type</span>
        <select
          value={markupType}
          onChange={(e) => setMarkupType(e.target.value as "PERCENTAGE" | "FIXED")}
          className="mt-1 w-full rounded-lg border border-line px-2 py-2 text-sm text-ink"
        >
          <option value="PERCENTAGE">Percentage</option>
          <option value="FIXED">Fixed (cents)</option>
        </select>
      </label>

      <label className="block">
        <span className="text-xs font-medium text-muted">{markupType === "PERCENTAGE" ? "Markup %" : "Markup (cents)"}</span>
        <input
          type="number"
          step="0.01"
          required
          value={markupValue}
          onChange={(e) => setMarkupValue(e.target.value)}
          className="mt-1 w-full rounded-lg border border-line px-2 py-2 text-sm text-ink"
        />
      </label>

      <label className="block">
        <span className="text-xs font-medium text-muted">Priority</span>
        <input
          type="number"
          value={priority}
          onChange={(e) => setPriority(e.target.value)}
          className="mt-1 w-full rounded-lg border border-line px-2 py-2 text-sm text-ink"
        />
      </label>

      <div className="col-span-2 flex items-end sm:col-span-1">
        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-full bg-horizon py-2 text-sm font-medium text-white hover:bg-horizon-dark disabled:opacity-60"
        >
          {loading ? "Adding…" : "Add rule"}
        </button>
      </div>

      {error && <p className="col-span-2 text-sm text-danger sm:col-span-6">{error}</p>}
    </form>
  );
}
