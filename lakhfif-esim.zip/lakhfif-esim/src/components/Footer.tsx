import Link from "next/link";

const columns = [
  {
    title: "Destinations",
    links: [
      { href: "/esim/usa", label: "USA" },
      { href: "/esim/uk", label: "United Kingdom" },
      { href: "/esim/france", label: "France" },
      { href: "/esim/morocco", label: "Morocco" },
      { href: "/plans", label: "All plans" },
    ],
  },
  {
    title: "Account",
    links: [
      { href: "/account/orders", label: "My orders" },
      { href: "/account/esims", label: "My eSIMs" },
      { href: "/login", label: "Log in" },
    ],
  },
  {
    title: "Company",
    links: [
      { href: "/terms", label: "Terms" },
      { href: "/privacy", label: "Privacy" },
      { href: "/refund-policy", label: "Refund policy" },
      { href: "/contact", label: "Contact" },
    ],
  },
];

export function Footer() {
  return (
    <footer className="border-t border-line bg-paper">
      <div className="mx-auto grid max-w-6xl grid-cols-2 gap-8 px-5 py-12 sm:grid-cols-4">
        <div className="col-span-2 sm:col-span-1">
          <p className="font-display text-base font-bold text-ink">
            Lakhfif <span className="text-horizon">eSIM</span>
          </p>
          <p className="mt-2 max-w-[22ch] text-sm text-muted">Global data, without the roaming bill.</p>
        </div>
        {columns.map((col) => (
          <div key={col.title}>
            <p className="text-sm font-semibold text-ink">{col.title}</p>
            <ul className="mt-3 space-y-2">
              {col.links.map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-sm text-muted hover:text-horizon">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-line px-5 py-5 text-center text-xs text-muted">
        © {new Date().getFullYear()} Lakhfif eSIM. All rights reserved.
      </div>
    </footer>
  );
}
