import Link from "next/link";
import { formatMoney, formatDataAmount } from "@/lib/utils";

export interface PlanCardData {
  id: string;
  dataAmount: number;
  dataUnit: string;
  validityDays: number;
  retailPrice: number;
  currency: string;
  network?: string | null;
  country: { name: string; flagEmoji: string | null } | null;
  region?: { name: string } | null;
}

export function PlanCard({ plan }: { plan: PlanCardData }) {
  const place = plan.country?.name ?? plan.region?.name ?? "Multi-country";

  return (
    <Link href={`/plans/${plan.id}`} className="ticket group block transition-shadow hover:shadow-md">
      <div className="ticket__main">
        <div className="flex items-center gap-2 text-sm text-muted">
          <span className="text-lg leading-none">{plan.country?.flagEmoji ?? "🌍"}</span>
          <span>{place}</span>
        </div>
        <p className="mt-2 font-display text-2xl font-semibold text-ink">
          {formatDataAmount(plan.dataAmount, plan.dataUnit)}
        </p>
        <p className="mt-1 text-sm text-muted">
          Valid {plan.validityDays} days{plan.network ? ` · ${plan.network}` : ""}
        </p>
      </div>
      <div className="ticket__stub">
        <p className="font-display text-lg font-bold text-horizon">{formatMoney(plan.retailPrice, plan.currency)}</p>
        <span className="text-xs font-medium text-muted group-hover:text-horizon">View plan</span>
      </div>
    </Link>
  );
}
