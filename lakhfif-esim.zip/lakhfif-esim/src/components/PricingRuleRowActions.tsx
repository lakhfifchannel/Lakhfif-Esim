"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export function PricingRuleRowActions({ id, isActive }: { id: string; isActive: boolean }) {
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function toggle() {
    setLoading(true);
    await fetch(`/api/admin/pricing-rules/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isActive: !isActive }),
    });
    setLoading(false);
    router.refresh();
  }

  async function remove() {
    if (!confirm("Delete this pricing rule?")) return;
    setLoading(true);
    await fetch(`/api/admin/pricing-rules/${id}`, { method: "DELETE" });
    setLoading(false);
    router.refresh();
  }

  return (
    <div className="flex items-center justify-end gap-2">
      <button
        type="button"
        onClick={toggle}
        disabled={loading}
        className="rounded-full border border-line px-3 py-1 text-xs font-medium text-ink hover:border-horizon hover:text-horizon disabled:opacity-60"
      >
        {isActive ? "Disable" : "Enable"}
      </button>
      <button
        type="button"
        onClick={remove}
        disabled={loading}
        className="rounded-full border border-line px-3 py-1 text-xs font-medium text-danger hover:border-danger disabled:opacity-60"
      >
        Delete
      </button>
    </div>
  );
}
