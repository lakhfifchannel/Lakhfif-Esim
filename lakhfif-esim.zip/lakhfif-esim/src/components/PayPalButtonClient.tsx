"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";

// Loaded via the vanilla PayPal JS SDK <script> tag rather than a React
// wrapper package, so there's no extra dependency to keep in sync with
// PayPal's own SDK releases.
declare global {
  interface Window {
    paypal?: {
      Buttons: (config: Record<string, unknown>) => { render: (el: HTMLElement) => void };
    };
  }
}

export function PayPalButtonClient({
  planId,
  clientId,
  currency,
}: {
  planId: string;
  clientId: string;
  currency: string;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [phase, setPhase] = useState<"loading" | "ready" | "processing" | "error">("loading");
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    let cancelled = false;
    let pendingOrderId: string | null = null;

    function renderButtons() {
      if (cancelled || !containerRef.current || !window.paypal) return;

      window.paypal
        .Buttons({
          style: { layout: "vertical", shape: "pill", label: "paypal" },

          createOrder: async () => {
            const res = await fetch("/api/checkout/create-order", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ planId }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error ?? "Could not start checkout");
            pendingOrderId = data.orderId as string;
            return data.paypalOrderId as string;
          },

          onApprove: async (data: { orderID: string }) => {
            setPhase("processing");
            // This request is what actually confirms and fulfills the
            // order server-side — the PayPal popup completing is not, by
            // itself, treated as a successful payment anywhere in this app.
            const res = await fetch("/api/checkout/capture", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ orderId: pendingOrderId, paypalOrderId: data.orderID }),
            });
            const result = await res.json().catch(() => null);
            if (!res.ok || !result || result.status === "FAILED") {
              router.push("/payment/failed");
              return;
            }
            router.push(`/payment/success?order=${encodeURIComponent(result.orderNumber)}`);
          },

          onCancel: () => setPhase("ready"),

          onError: () => {
            setError("Something went wrong with PayPal. Please try again.");
            setPhase("error");
          },
        })
        .render(containerRef.current);

      setPhase("ready");
    }

    const existing = document.getElementById("paypal-sdk") as HTMLScriptElement | null;
    if (window.paypal) {
      renderButtons();
    } else if (existing) {
      existing.addEventListener("load", renderButtons);
    } else {
      const script = document.createElement("script");
      script.id = "paypal-sdk";
      script.src = `https://www.paypal.com/sdk/js?client-id=${encodeURIComponent(clientId)}&currency=${encodeURIComponent(currency)}&intent=capture`;
      script.addEventListener("load", renderButtons);
      script.addEventListener("error", () => {
        setError("Could not load PayPal. Check your connection and try again.");
        setPhase("error");
      });
      document.body.appendChild(script);
    }

    return () => {
      cancelled = true;
    };
  }, [planId, clientId, currency, router]);

  return (
    <div>
      {phase === "loading" && <p className="text-sm text-muted">Loading PayPal…</p>}
      {phase === "processing" && (
        <p className="text-sm font-medium text-horizon">Confirming your payment — don&apos;t close this page…</p>
      )}
      {error && <p className="mb-2 text-sm text-danger">{error}</p>}
      <div ref={containerRef} />
    </div>
  );
}
