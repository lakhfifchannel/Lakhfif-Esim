"use client";

import { useMemo, useState } from "react";
import Link from "next/link";

export interface SearchableCountry {
  name: string;
  slug: string;
  flagEmoji: string | null;
}

export function CountrySearch({ countries }: { countries: SearchableCountry[] }) {
  const [query, setQuery] = useState("");
  const [focused, setFocused] = useState(false);

  const matches = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return countries;
    return countries.filter((c) => c.name.toLowerCase().includes(q));
  }, [query, countries]);

  return (
    <div className="relative w-full max-w-md">
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        onFocus={() => setFocused(true)}
        onBlur={() => setTimeout(() => setFocused(false), 150)}
        placeholder="Where are you traveling?"
        aria-label="Search for a destination"
        className="w-full rounded-full border border-line bg-white px-5 py-3.5 text-base text-ink shadow-sm outline-none placeholder:text-muted focus-visible:border-horizon"
      />
      {focused && matches.length > 0 && (
        <ul className="absolute z-10 mt-2 max-h-72 w-full overflow-auto rounded-2xl border border-line bg-white p-2 shadow-lg">
          {matches.slice(0, 8).map((country) => (
            <li key={country.slug}>
              <Link
                href={`/esim/${country.slug}`}
                className="flex items-center gap-3 rounded-xl px-3 py-2 text-sm text-ink hover:bg-cloud"
              >
                <span className="text-lg leading-none">{country.flagEmoji ?? "🌍"}</span>
                {country.name}
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
