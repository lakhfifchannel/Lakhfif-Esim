// All money in this codebase is stored as an integer in the currency's
// minor unit (cents for USD/EUR, pence for GBP) — see ARCHITECTURE.md
// section "Money". Never store or compare floats for prices.

export function formatMoney(minorUnits: number, currency: string): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    currencyDisplay: "symbol",
  }).format(minorUnits / 100);
}

export function toMinorUnits(amount: number): number {
  return Math.round(amount * 100);
}

/** "ORDER-10001" style human-facing order numbers. The database id (cuid)
 * stays the real primary key; this is only a display/reference label.
 * The numeric part comes from the Counter row (see order.service.ts),
 * incremented atomically in the same transaction that creates the order. */
export function formatOrderNumber(counterValue: number | bigint): string {
  return `ORDER-${Number(counterValue)}`;
}

export function slugify(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)+/g, "");
}

export function formatDataAmount(amount: number, unit: string): string {
  if (unit === "UNLIMITED") return "Unlimited";
  return `${amount % 1 === 0 ? amount : amount.toFixed(1)}${unit}`;
}

export function assertNever(value: never): never {
  throw new Error(`Unexpected value: ${JSON.stringify(value)}`);
}
