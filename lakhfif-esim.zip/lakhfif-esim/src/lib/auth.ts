import "server-only";
import { SignJWT, jwtVerify } from "jose";
import bcrypt from "bcryptjs";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import type { AdminRole } from "@prisma/client";
import { env } from "./env";

// We deliberately don't use a middleware/proxy layer to gate these routes.
// Next.js 16 renamed middleware.ts -> proxy.ts and explicitly narrowed it to
// network-level concerns (rewrites, headers) rather than auth, because
// edge-only checks have historically been bypassable (CVE-2025-29927).
// Every protected layout and every protected Route Handler below calls one
// of the require*() / get*() functions in this file directly, server-side.

const CUSTOMER_COOKIE = "lakhfif_session";
const ADMIN_COOKIE = "lakhfif_admin_session";
const SESSION_SECONDS = 60 * 60 * 24 * 30; // 30 days

export interface CustomerSession {
  sub: string; // User.id
  email: string;
  kind: "customer";
}

export interface AdminSession {
  sub: string; // AdminUser.id
  email: string;
  role: AdminRole;
  kind: "admin";
}

function secretKey() {
  return new TextEncoder().encode(env.authSecret);
}

// ---- passwords -------------------------------------------------------

export function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

export function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

// ---- token sign / verify ----------------------------------------------

async function sign(payload: Record<string, unknown>): Promise<string> {
  return new SignJWT(payload)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(`${SESSION_SECONDS}s`)
    .sign(secretKey());
}

async function verify<T>(token: string): Promise<T | null> {
  try {
    const { payload } = await jwtVerify(token, secretKey());
    return payload as unknown as T;
  } catch {
    return null;
  }
}

// ---- customer session ---------------------------------------------------

export async function createCustomerSession(user: { id: string; email: string }) {
  const token = await sign({ sub: user.id, email: user.email, kind: "customer" });
  const store = await cookies();
  store.set(CUSTOMER_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_SECONDS,
  });
}

export async function destroyCustomerSession() {
  const store = await cookies();
  store.delete(CUSTOMER_COOKIE);
}

export async function getCustomerSession(): Promise<CustomerSession | null> {
  const store = await cookies();
  const token = store.get(CUSTOMER_COOKIE)?.value;
  if (!token) return null;
  const payload = await verify<CustomerSession>(token);
  return payload?.kind === "customer" ? payload : null;
}

/** For Server Components / layouts: redirects if not logged in. */
export async function requireCustomerSession(): Promise<CustomerSession> {
  const session = await getCustomerSession();
  if (!session) redirect("/login");
  return session;
}

// ---- admin session -----------------------------------------------------

export async function createAdminSession(admin: {
  id: string;
  email: string;
  role: AdminRole;
}) {
  const token = await sign({
    sub: admin.id,
    email: admin.email,
    role: admin.role,
    kind: "admin",
  });
  const store = await cookies();
  store.set(ADMIN_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_SECONDS,
  });
}

export async function destroyAdminSession() {
  const store = await cookies();
  store.delete(ADMIN_COOKIE);
}

export async function getAdminSession(): Promise<AdminSession | null> {
  const store = await cookies();
  const token = store.get(ADMIN_COOKIE)?.value;
  if (!token) return null;
  const payload = await verify<AdminSession>(token);
  return payload?.kind === "admin" ? payload : null;
}

/** For Server Components / layouts. Pass `roles` to further restrict a
 * page to specific AdminRole values (e.g. FINANCE-only refund tools). */
export async function requireAdminSession(roles?: AdminRole[]): Promise<AdminSession> {
  const session = await getAdminSession();
  if (!session) redirect("/admin/login");
  if (roles && !roles.includes(session.role)) redirect("/admin");
  return session;
}
