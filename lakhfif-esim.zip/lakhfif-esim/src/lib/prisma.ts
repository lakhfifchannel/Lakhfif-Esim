import { PrismaClient } from "@prisma/client";

// Next.js dev-mode hot reload re-executes this module often; without
// caching the client on `globalThis` every reload would open a fresh
// pool of Postgres connections until the database refuses new ones.
const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["warn", "error"] : ["error"],
  });

if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = prisma;
}
