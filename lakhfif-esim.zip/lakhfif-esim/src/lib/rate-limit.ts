import "server-only";

interface Bucket {
  count: number;
  resetAt: number;
}

// Process-local state. Fine for a single instance / development. A
// multi-instance production deployment needs a shared store (Redis,
// Upstash) instead — this map doesn't survive a restart or get shared
// across instances, so treat this as a baseline, not the final word.
const buckets = new Map<string, Bucket>();

let sweepScheduled = false;
function scheduleSweep() {
  if (sweepScheduled) return;
  sweepScheduled = true;
  const timer = setInterval(() => {
    const now = Date.now();
    for (const [key, bucket] of buckets) {
      if (bucket.resetAt < now) buckets.delete(key);
    }
  }, 5 * 60 * 1000);
  timer.unref?.();
}

export interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  resetAt: number;
}

/** Fixed-window limiter: `limit` requests per `windowMs`, keyed however
 * the caller likes (usually IP + route name, via clientKey() below). */
export function rateLimit(key: string, limit: number, windowMs: number): RateLimitResult {
  scheduleSweep();
  const now = Date.now();
  const existing = buckets.get(key);

  if (!existing || existing.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return { allowed: true, remaining: limit - 1, resetAt: now + windowMs };
  }

  existing.count += 1;
  return {
    allowed: existing.count <= limit,
    remaining: Math.max(limit - existing.count, 0),
    resetAt: existing.resetAt,
  };
}

/** Best-effort caller IP from standard proxy headers. Falls back to a
 * shared bucket if none is present, so the limit still applies (just
 * more conservatively) rather than being silently skipped. */
export function clientKey(req: Request): string {
  const forwarded = req.headers.get("x-forwarded-for");
  return forwarded?.split(",")[0]?.trim() || req.headers.get("x-real-ip") || "unknown";
}
