// Central, typed access to environment variables.
//
// Reading `process.env.X` directly scattered across the codebase means a
// missing var silently becomes `undefined` and fails somewhere confusing
// (e.g. inside a PayPal signature check). Route everything through here so
// a misconfigured deployment fails loudly, at startup of the code path that
// needs it, with a message that says exactly what's missing.

function required(name: string, fallback?: string): string {
  const value = process.env[name] ?? fallback;
  if (!value) {
    throw new Error(
      `Missing required environment variable: ${name}. Check .env against .env.example.`
    );
  }
  return value;
}

function optional(name: string, fallback = ""): string {
  return process.env[name] ?? fallback;
}

export const env = {
  get appUrl() {
    return optional("APP_URL", "http://localhost:3000");
  },
  get databaseUrl() {
    return required("DATABASE_URL");
  },

  // Auth — accepts either name so teams used to the NextAuth convention
  // don't have to rename anything.
  get authSecret() {
    return required("AUTH_SECRET", process.env.NEXTAUTH_SECRET);
  },

  // PayPal
  get paypalEnv(): "sandbox" | "live" {
    return optional("PAYPAL_ENV", "sandbox") === "live" ? "live" : "sandbox";
  },
  get paypalClientId() {
    return required("PAYPAL_CLIENT_ID");
  },
  get paypalClientSecret() {
    return required("PAYPAL_CLIENT_SECRET");
  },
  get paypalWebhookId() {
    return required("PAYPAL_WEBHOOK_ID");
  },
  get defaultCurrency() {
    return optional("DEFAULT_CURRENCY", "USD");
  },

  // eSIM provider
  get esimProviderMode(): "mock" | "aggregator" {
    return optional("ESIM_PROVIDER_MODE", "mock") === "aggregator"
      ? "aggregator"
      : "mock";
  },
  get esimProviderApiKey() {
    return optional("ESIM_PROVIDER_API_KEY");
  },
  get esimProviderApiUrl() {
    return optional("ESIM_PROVIDER_API_URL");
  },
  get esimProviderWebhookSecret() {
    return optional("ESIM_PROVIDER_WEBHOOK_SECRET");
  },

  // Email
  get emailProvider(): "console" | "resend" {
    return optional("EMAIL_PROVIDER", "console") === "resend"
      ? "resend"
      : "console";
  },
  get emailApiKey() {
    return optional("EMAIL_API_KEY");
  },
  get emailFrom() {
    return optional("EMAIL_FROM", "Lakhfif eSIM <orders@lakhfif.example>");
  },
  get supportEmail() {
    return optional("SUPPORT_EMAIL", "support@lakhfif.example");
  },

  // Cron
  get cronSecret() {
    return optional("CRON_SECRET");
  },
};

export const PAYPAL_API_BASE =
  env.paypalEnv === "live"
    ? "https://api-m.paypal.com"
    : "https://api-m.sandbox.paypal.com";
