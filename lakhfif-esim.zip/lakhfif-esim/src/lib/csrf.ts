import "server-only";
import { env } from "./env";

/**
 * Rejects a mutating request whose Origin (or, failing that, Referer)
 * doesn't match this app's own origin. Browsers attach Origin to every
 * cross-site fetch/XHR and can't be made to lie about it from page
 * JavaScript, so this is a reliable signal.
 *
 * This is deliberately not used on the webhook routes — PayPal and the
 * eSIM provider call those directly, server-to-server, with no browser
 * Origin header at all; those routes are protected by signature/secret
 * verification instead, which is the correct mechanism for that case.
 *
 * Combined with every mutating route requiring an httpOnly session
 * cookie AND a JSON body (which a plain cross-origin HTML <form> cannot
 * send), this closes the classic CSRF vector: a same-site-cookie request
 * forged from another origin.
 */
export function verifyOrigin(req: Request): boolean {
  const appOrigin = new URL(env.appUrl).origin;
  const origin = req.headers.get("origin");
  if (origin) return origin === appOrigin;

  const referer = req.headers.get("referer");
  if (referer) return referer.startsWith(appOrigin);

  // Neither header present: a real same-origin fetch/XHR always sends at
  // least one, so treat this as suspicious rather than assume it's fine.
  return false;
}
