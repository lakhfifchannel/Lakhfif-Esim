import type { Config } from "tailwindcss";

// Design tokens for Lakhfif eSIM.
// Palette: a dusk-departure navy + boarding-pass amber, instead of the
// default cream/terracotta or dark/neon SaaS look. Plan cards use a
// boarding-pass "ticket stub" motif as the one bold, recurring device.
const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#14182B", // primary text, dark surfaces
        cloud: "#F5F6FA", // page background
        paper: "#FFFFFF", // card surfaces
        horizon: {
          DEFAULT: "#263873", // primary brand / CTAs
          dark: "#1B2757",
          light: "#3B4E9C",
        },
        amber: {
          DEFAULT: "#E0A458", // single sparing accent
          dark: "#C4863A",
        },
        signal: {
          DEFAULT: "#2F8F86", // status / success / data indicators
          light: "#E4F3F1",
        },
        line: "#DFE2EC", // hairline borders on light surfaces
        muted: "#6B7089",
        danger: "#C0392B",
      },
      fontFamily: {
        display: ["var(--font-display)", "sans-serif"],
        sans: ["var(--font-body)", "sans-serif"],
      },
      borderRadius: {
        card: "10px",
        stub: "4px",
      },
      maxWidth: {
        prose: "72ch",
      },
    },
  },
  plugins: [],
};

export default config;
