import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import { MOCK_CATALOGUE } from "../src/services/esim/providers/mock-provider";

const prisma = new PrismaClient();

const REGIONS = [
  { name: "Europe", slug: "europe" },
  { name: "Americas", slug: "americas" },
  { name: "Asia", slug: "asia" },
  { name: "Middle East", slug: "middle-east" },
  { name: "Africa", slug: "africa" },
];

const COUNTRIES: { name: string; code: string; slug: string; flagEmoji: string; regionSlug: string }[] = [
  { name: "United States", code: "US", slug: "usa", flagEmoji: "🇺🇸", regionSlug: "americas" },
  { name: "United Kingdom", code: "GB", slug: "uk", flagEmoji: "🇬🇧", regionSlug: "europe" },
  { name: "France", code: "FR", slug: "france", flagEmoji: "🇫🇷", regionSlug: "europe" },
  { name: "Spain", code: "ES", slug: "spain", flagEmoji: "🇪🇸", regionSlug: "europe" },
  { name: "Italy", code: "IT", slug: "italy", flagEmoji: "🇮🇹", regionSlug: "europe" },
  { name: "Turkey", code: "TR", slug: "turkey", flagEmoji: "🇹🇷", regionSlug: "europe" },
  { name: "United Arab Emirates", code: "AE", slug: "uae", flagEmoji: "🇦🇪", regionSlug: "middle-east" },
  { name: "Morocco", code: "MA", slug: "morocco", flagEmoji: "🇲🇦", regionSlug: "africa" },
  { name: "Japan", code: "JP", slug: "japan", flagEmoji: "🇯🇵", regionSlug: "asia" },
  { name: "Thailand", code: "TH", slug: "thailand", flagEmoji: "🇹🇭", regionSlug: "asia" },
];

async function main() {
  console.log("Seeding regions...");
  const regionBySlug = new Map<string, string>();
  for (const region of REGIONS) {
    const row = await prisma.region.upsert({
      where: { slug: region.slug },
      update: { name: region.name },
      create: region,
    });
    regionBySlug.set(region.slug, row.id);
  }

  console.log("Seeding countries...");
  const countryByCode = new Map<string, string>();
  for (const country of COUNTRIES) {
    const row = await prisma.country.upsert({
      where: { code: country.code },
      update: {
        name: country.name,
        slug: country.slug,
        flagEmoji: country.flagEmoji,
        regionId: regionBySlug.get(country.regionSlug),
      },
      create: {
        name: country.name,
        code: country.code,
        slug: country.slug,
        flagEmoji: country.flagEmoji,
        regionId: regionBySlug.get(country.regionSlug),
      },
    });
    countryByCode.set(country.code, row.id);
  }

  console.log("Seeding the mock provider...");
  const mockProvider = await prisma.provider.upsert({
    where: { code: "mock" },
    update: { name: "Mock Provider", billingMode: "PREPAID", isActive: true },
    create: { name: "Mock Provider", code: "mock", billingMode: "PREPAID", isActive: true },
  });

  console.log(`Seeding ${MOCK_CATALOGUE.length} plans from the mock catalogue...`);
  for (const plan of MOCK_CATALOGUE) {
    await prisma.plan.upsert({
      where: { providerId_providerPlanId: { providerId: mockProvider.id, providerPlanId: plan.providerPlanId } },
      update: {
        countryId: plan.countryCode ? countryByCode.get(plan.countryCode) : null,
        dataAmount: plan.dataAmount,
        dataUnit: plan.dataUnit,
        validityDays: plan.validityDays,
        wholesalePrice: plan.wholesalePrice,
        currency: plan.currency,
        network: plan.network,
        activationType: plan.activationType,
        supportedDevices: plan.supportedDevices,
        planType: plan.planType,
        isActive: true,
      },
      create: {
        providerId: mockProvider.id,
        providerPlanId: plan.providerPlanId,
        countryId: plan.countryCode ? countryByCode.get(plan.countryCode) : null,
        coverage: plan.coverage,
        dataAmount: plan.dataAmount,
        dataUnit: plan.dataUnit,
        validityDays: plan.validityDays,
        wholesalePrice: plan.wholesalePrice,
        retailPrice: plan.wholesalePrice, // placeholder; recomputed below via the pricing rule
        currency: plan.currency,
        network: plan.network,
        activationType: plan.activationType,
        supportedDevices: plan.supportedDevices,
        planType: plan.planType,
      },
    });
  }

  console.log("Seeding a default global pricing rule (40% markup, matching the spec's own example)...");
  const existingGlobalRule = await prisma.pricingRule.findFirst({ where: { scope: "GLOBAL", isActive: true } });
  if (!existingGlobalRule) {
    await prisma.pricingRule.create({
      data: { scope: "GLOBAL", markupType: "PERCENTAGE", markupValue: 40, priority: 0, isActive: true },
    });
  }

  console.log("Recomputing retail prices from pricing rules...");
  const allPlans = await prisma.plan.findMany();
  for (const plan of allPlans) {
    const rules = await prisma.pricingRule.findMany({ where: { isActive: true } });
    const applicable = rules.filter((r) => r.scope === "GLOBAL"); // only rule seeded above; full logic lives in pricing.service.ts
    if (applicable.length > 0) {
      const rule = applicable[0]!;
      const retailPrice =
        rule.markupType === "PERCENTAGE"
          ? Math.round(plan.wholesalePrice * (1 + rule.markupValue / 100))
          : Math.round(plan.wholesalePrice + rule.markupValue);
      await prisma.plan.update({ where: { id: plan.id }, data: { retailPrice } });
    }
  }

  const adminEmail = (process.env.ADMIN_SEED_EMAIL ?? "admin@lakhfif.example").toLowerCase();
  const adminPassword = process.env.ADMIN_SEED_PASSWORD ?? "change-me-immediately";
  console.log(`Seeding the first admin account (${adminEmail})...`);
  await prisma.adminUser.upsert({
    where: { email: adminEmail },
    update: {},
    create: {
      email: adminEmail,
      passwordHash: await bcrypt.hash(adminPassword, 12),
      name: "Super Admin",
      role: "SUPER_ADMIN",
    },
  });

  console.log("Seeding a demo customer account (demo@lakhfif.example / demo12345)...");
  await prisma.user.upsert({
    where: { email: "demo@lakhfif.example" },
    update: {},
    create: {
      email: "demo@lakhfif.example",
      passwordHash: await bcrypt.hash("demo12345", 12),
      name: "Demo Traveler",
    },
  });

  console.log("Done.");
}

main()
  .catch((err) => {
    console.error(err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
