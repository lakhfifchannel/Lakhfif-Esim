# Lakhfif eSIM — Architecture

This is a staged build. This first pass delivers: the full architecture and
database schema (this document + `prisma/schema.prisma`), a complete and
independently-tested payment/fulfillment backend, a working mock eSIM
provider, and a functional customer + admin frontend covering the core
buy → pay → receive flow end to end. **"What's not built yet"** at the
bottom of this document is the honest list of what a production launch
still needs on top of this.

## 1. Tech stack, and why

| Concern | Choice | Why |
|---|---|---|
| Framework | Next.js 16 (App Router, Turbopack) | One codebase for the customer site, admin panel, and API — Route Handlers give explicit, independently-testable endpoints for every state change. |
| Language | TypeScript, strict mode | The payment/fulfillment state machine is exactly the kind of logic where a typo becomes a double charge; strict types catch a lot of that at compile time. |
| Database | PostgreSQL via Prisma | Spec requirement. Prisma gives migrations, a typed client, and transactions. |
| Auth | Hand-rolled (bcryptjs + `jose` JWTs in httpOnly cookies), not NextAuth/Auth.js | At the time of writing, Auth.js v5 — the version needed for clean App Router support — is still on npm's `beta` tag, and v4's App Router support is a bolt-on. For two principal types (customers and admin staff) with separate sessions, a ~150-line auth module (`src/lib/auth.ts`) is less risk than pinning a production app to a pre-1.0 dependency. Passwords are bcrypt-hashed; sessions are signed JWTs in separate httpOnly cookies per surface. |
| Payments | Direct PayPal REST calls (`/v2/checkout/orders`, `/v1/notifications/verify-webhook-signature`), no SDK package | PayPal's REST contract is stable; a hand-rolled client (`src/services/payment/paypal.ts`) avoids taking on an SDK's own versioning. |
| eSIM provider | Custom abstraction (`ESIMProvider` interface) + a full mock implementation | Spec requirement — see section 4. |
| Email | Custom `EmailProvider` interface; `console` (dev) and `Resend` (via plain REST) implementations | Swappable, no SDK dependency. |
| Styling | Tailwind CSS | Fast to build a distinctive, consistent UI without a component library dependency. |

## 2. Layered architecture

```mermaid
flowchart TD
    FE["Frontend (Next.js pages, Server Components)"]
    API["API Route Handlers (/api/**)"]
    ORDER["Order Service<br/>(order.service.ts, fulfillment.service.ts)"]
    PRICING["Pricing Service"]
    PAY["Payment Service<br/>(paypal.ts)"]
    ESIM["eSIM Provider Abstraction<br/>(ESIMProvider interface)"]
    EMAIL["Email Service"]
    DB[(PostgreSQL via Prisma)]
    PAYPAL[["PayPal REST API"]]
    PROVIDER[["Mock / real eSIM aggregator"]]

    FE --> API
    API --> ORDER
    API --> PAY
    ORDER --> PRICING
    ORDER --> ESIM
    ORDER --> EMAIL
    ORDER --> DB
    PRICING --> DB
    PAY --> PAYPAL
    ESIM --> PROVIDER
```

Route Handlers are intentionally thin: they authenticate the caller, validate
input, and call into a service. All the actual business logic — and every
place a race condition could cause a double charge or a duplicate purchase
— lives in `src/services/`, where it's one code path regardless of which
route (or which webhook) triggered it.

## 3. Directory structure

```
prisma/
  schema.prisma          # full schema — see section 6 below
  seed.ts                 # regions, countries, mock plans, pricing rule, admin/demo accounts
src/
  app/
    (customer pages)       # /, /plans, /plans/[id], /checkout/[planId],
                            # /payment/success, /payment/failed,
                            # /account/*, /esim/[country], /login, /register
    admin/
      login/                # outside the auth guard
      (guarded)/            # route group — every page here requires an admin session
    api/
      auth/                 # register, login, admin-login, logout
      plans/                 # public catalogue read
      checkout/              # create-order, capture
      webhooks/               # paypal, esim-provider
      admin/orders/[id]/retry/
  lib/                      # prisma client, auth, env, small utils
  services/
    esim/                   # provider interface, factory, mock + example adapters
    payment/                 # paypal.ts
    pricing/                  # pricing.service.ts
    order/                    # order.service.ts, fulfillment.service.ts
    email/                     # provider abstraction + templates
  components/                # PlanCard, PayPalButtonClient, QRCodeDisplay, etc.
```

## 4. The eSIM provider abstraction

```ts
interface ESIMProvider {
  getPlans(): Promise<NormalizedPlan[]>;
  getPlan(providerPlanId: string): Promise<NormalizedPlan | null>;
  createOrder(order: ProviderOrderRequest): Promise<ProviderOrderResult>;
  getOrder(providerOrderId: string): Promise<ProviderOrderResult>;
  getESIM(providerEsimId: string): Promise<ProviderESIMDetails>;
  getUsage(providerEsimId: string): Promise<ProviderUsage>;
  getStatus(providerEsimId: string): Promise<ProviderESIMStatus>;
}
```

`src/services/esim/provider.factory.ts` is the **only** place that decides
which implementation is live, controlled by `ESIM_PROVIDER_MODE`:

- `mock` (default) → `MockESIMProvider` — a full deterministic simulation
  (see its file header for the `*-fail` / `*-insufficient` / `*-delay` test
  hooks) so the entire flow works with zero external accounts.
- `aggregator` → `ExampleAggregatorProvider` — a **template**, not a real
  integration. It shows the auth pattern, the request/response mapping
  step, and error handling, using placeholder endpoint names. Nobody
  should trust its exact field names — replace them with your chosen
  aggregator's real documented API once you pick one.

Every upstream plan is normalized into one shape (`NormalizedPlan`) before
anything else in the app sees it — pricing, order creation, and the
frontend never touch a provider's native response format. That's what lets
a second aggregator be added later by writing one new adapter file.

`Provider` rows in the database represent the underlying carriers your
aggregator exposes (for billing-mode and reporting purposes); the actual
API calls all go through the one configured `ESIMProvider` instance, per
the spec's "one aggregator, multiple underlying providers" model.

## 5. Payment flow — and one deliberate refinement

The requested flow is: pay → PayPal confirms → webhook → verify → *then*
provision. This build implements that, plus one addition worth calling
out explicitly:

**Fulfillment is triggered from two places — the capture Route Handler
*and* the PayPal webhook — both calling the same idempotent
`fulfillOrder()`.** Relying on the webhook alone is the textbook-correct
design, but it has a real failure mode: if the webhook is delayed (PayPal
webhooks are typically fast but not instant) or your server misses it
before PayPal's retry window, the customer is left staring at a spinner
for no good reason. Calling `fulfillOrder()` right after our own
server-to-server capture succeeds gives an instant result in the common
case; the webhook remains the authoritative backstop for every case where
that doesn't happen (tab closed mid-flow, function timeout, etc.).

This is safe *only* because of how the claiming works:

```mermaid
sequenceDiagram
    participant C as Customer (browser)
    participant API as /api/checkout/capture
    participant PP as PayPal API
    participant WH as /api/webhooks/paypal
    participant DB as Postgres

    C->>API: POST {orderId, paypalOrderId}
    API->>PP: Capture order (server-to-server)
    PP-->>API: status: COMPLETED
    API->>DB: markOrderPaid() — atomic claim (PENDING_PAYMENT/PAYMENT_PROCESSING -> PAID)
    API->>DB: fulfillOrder() — atomic claim (PAID/PROVIDER_PENDING -> PROVIDER_PROCESSING)
    API-->>C: { status: "FULFILLED" }
    PP-->>WH: PAYMENT.CAPTURE.COMPLETED (async, arrives independently)
    WH->>DB: markOrderPaid() — claim fails (already PAID), no-op
    WH->>DB: fulfillOrder() — claim fails (already processed), no-op
```

Both `markOrderPaid()` and `fulfillOrder()` claim their work with a single
conditional `UPDATE ... WHERE status IN (...)` rather than a
read-then-write — so whichever caller's `UPDATE` reaches Postgres first
"wins" the row, and the other sees zero rows affected and safely does
nothing. No advisory locks or distributed locks needed; this is standard
Postgres row-level locking on a single statement.

The webhook's signature is verified by calling PayPal's own
`/v1/notifications/verify-webhook-signature` endpoint rather than
re-implementing the crypto locally. Every webhook event is stored with
PayPal's own event id as a unique key before any processing happens, so a
retried delivery is detected and skipped, never reprocessed.

## 6. Order lifecycle

```mermaid
stateDiagram-v2
    [*] --> PENDING_PAYMENT
    PENDING_PAYMENT --> PAYMENT_PROCESSING
    PAYMENT_PROCESSING --> PAID: PayPal capture confirmed
    PENDING_PAYMENT --> FAILED: capture declined
    PAYMENT_PROCESSING --> FAILED: capture declined
    PAID --> PROVIDER_PROCESSING: fulfillOrder() claims it
    PROVIDER_PROCESSING --> FULFILLED: every item provisioned
    PROVIDER_PROCESSING --> PROVIDER_PENDING: any item failed / insufficient balance / provider pending
    PROVIDER_PENDING --> PROVIDER_PROCESSING: retry (admin, or async provider webhook)
    FULFILLED --> REFUND_PENDING
    PROVIDER_PENDING --> REFUND_PENDING
    REFUND_PENDING --> REFUNDED: PayPal refund webhook
```

The full schema (all 17 tables/enums — Users, AdminUsers, Orders,
OrderItems, Plans, Providers, ESIMs, Payments, PayPalTransactions,
ProviderTransactions, UsageRecords, Countries, Regions, PricingRules,
Webhooks, AuditLogs, plus a small Counter helper table for order numbers)
lives in `prisma/schema.prisma` — every field there has a comment
explaining its purpose.

## 7. Pricing engine

`PricingRule` rows are scoped to `GLOBAL | REGION | COUNTRY | PROVIDER |
DATA_AMOUNT | PLAN`, each with a `PERCENTAGE` or `FIXED` markup and an
admin-settable `priority`. `computeRetailPrice()` in
`src/services/pricing/pricing.service.ts` picks the highest-priority
matching rule, breaking ties by specificity (a plan-specific override beats
a global default). Wholesale price is never sent to the frontend — every
public API selects an explicit field list rather than returning a full
Plan row, precisely so a future field addition to the schema doesn't
accidentally leak into a public response. The resolved price is snapshotted
onto `OrderItem.unitPriceSnapshot` at checkout, so a later pricing-rule
change can never alter what an existing order is charged.

## 8. Security measures implemented

- Passwords: bcrypt, cost factor 12.
- Sessions: signed JWTs (`jose`, HS256) in httpOnly, `secure` (in
  production), `sameSite=lax` cookies — separate cookies for customers and
  admin staff, so a bug in one surface can't grant access to the other.
- Every `/account/*` and `/admin/*` page checks its session **in the page
  itself** (via a layout), not in `middleware.ts`/`proxy.ts` — Next.js 16
  narrowed proxy/middleware to network-level concerns after CVE-2025-29927
  showed edge-only auth checks can be bypassed. Every mutating API route
  re-checks its own session independently too, rather than trusting that a
  page-level guard was hit first.
- PayPal webhook signature verified via PayPal's own API; provider webhook
  behind a shared-secret header (swap for the real provider's actual
  signature scheme once one is chosen).
- All secrets read through `src/lib/env.ts`, never inlined; nothing
  provider- or PayPal-secret-shaped is ever sent to the frontend (the
  PayPal *Client ID* is intentionally public — that's how PayPal's own SDK
  is designed to work).
- Every state-changing Route Handler validates its input with `zod`.
- CSRF: every mutating route checks `Origin`/`Referer` against the app's
  own origin (`src/lib/csrf.ts`) before doing anything else.
- Rate limiting on login, admin login, registration, checkout creation,
  contact, and both password-reset endpoints (`src/lib/rate-limit.ts`).
- `AuditLog` rows are written for order creation, payment confirmation,
  every provider outcome, admin retries, and refunds.

## 9. Getting started

```bash
cp .env.example .env        # fill in AUTH_SECRET (openssl rand -base64 32)
                             # and PayPal sandbox credentials
npm install
npm run prisma:migrate      # creates the schema
npm run seed                # regions, countries, mock plans, pricing rule,
                             # admin + demo accounts
npm run dev
```

`ESIM_PROVIDER_MODE=mock` is the default — the full browse → checkout →
PayPal Sandbox → webhook → mock provider → eSIM delivered flow (spec
section 21) works with just PayPal sandbox credentials and nothing else.
Admin panel: `/admin/login` (seeded credentials from `ADMIN_SEED_EMAIL` /
`ADMIN_SEED_PASSWORD`). Demo customer login: `demo@lakhfif.example` /
`demo12345`.

## 10. What's not built yet, and what genuinely can't be from here

Two different kinds of "not done." The first is more building — I can do
this without anything from you:

- **Provider config UI** — connecting a real aggregator (below) is still a
  code + `.env` change, not an admin-panel form.
- **A real job queue.** `POST /api/admin/cron/sweep-pending` (secured with
  `CRON_SECRET`) now re-attempts stale `PROVIDER_PENDING` orders on a
  timer via any host's cron feature — a real dependency-free improvement
  over "only retried inline or by hand" — but it's still polling, not a
  proper queue (BullMQ, Inngest, etc.) with backoff and concurrency
  control. Fine at MVP scale; worth revisiting under real load.
- **Rate limiting is in-memory** (`src/lib/rate-limit.ts`). Fine for one
  instance; a multi-instance production deployment needs a shared store
  (Redis/Upstash) instead.
- **CSRF**: every mutating route now checks `Origin`/`Referer` against the
  app's own origin (`src/lib/csrf.ts`), on top of the session-cookie +
  JSON-body combination that already ruled out classic auto-submitting-form
  CSRF. Webhook and cron routes are deliberately excluded — they're
  server-to-server and authenticate via signature/secret instead, which is
  the correct mechanism for that case, not origin checking.

The second kind is genuinely blocked on you, not on more effort from me:

- **A real eSIM aggregator.** `ExampleAggregatorProvider` is a template
  with placeholder endpoint names — I don't have a real aggregator's
  actual API contract to wire it to. Once you pick one, send me its API
  docs and I'll fill it in for real.
- **Live PayPal credentials and an actual deployment.** I can't create a
  PayPal business account, a production domain, or hosting on your
  behalf — those are yours to set up (see "Deploying" in the README),
  after which the app itself needs no further code changes to go live.
- **Running `npm install` / `next build` here.** This environment has no
  network access, so I can't install dependencies or run the TypeScript
  compiler to get a machine-verified "it compiles" guarantee. Every file
  has been checked by hand instead (import resolution, Prisma relation
  usage, enum values, JSX escaping) and several real bugs were caught
  this way — but running `npm run typecheck` yourself after `npm install`
  is still worth doing before you deploy.

What *is* now built, beyond the original MVP pass: the pricing-rules
editor (`/admin/pricing`), the admin refund action (full or partial), a
webhooks log viewer (`/admin/webhooks`), a customers list
(`/admin/customers`), the forgot/reset-password flow, the
Terms/Privacy/Refund-policy/Contact pages (Contact is a working form that
emails support), CSRF origin-checking, and the cron sweep endpoint for
stuck orders. One thing still genuinely missing rather than deferred:
provider-balance visibility ("view provider balance if the API supports
it") — that's inherently provider-specific and waits on a real aggregator
being connected.
