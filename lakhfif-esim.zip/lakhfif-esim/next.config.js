/** @type {import('next').NextConfig} */
const nextConfig = {
  // Server Actions aren't used for payment-sensitive mutations on purpose —
  // every state-changing write goes through an explicit, independently
  // authenticated Route Handler so it's easy to reason about and audit.
  //
  // No eslint config ships in this scaffold (avoiding guessing at the
  // exact eslint-config-next / flat-config setup this Next.js version
  // expects without being able to verify it). Run `npx next lint` once to
  // generate one when you're ready, then flip this back to false.
  eslint: {
    ignoreDuringBuilds: true,
  },
};

module.exports = nextConfig;
