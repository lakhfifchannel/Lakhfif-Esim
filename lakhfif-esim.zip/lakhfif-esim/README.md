# Lakhfif eSIM

A global eSIM marketplace: browse plans by country, pay with PayPal, and
get your eSIM delivered instantly as a QR code. Built with a pluggable
provider abstraction so any eSIM aggregator API can be connected later
without touching payment, pricing, or order logic.

See **[ARCHITECTURE.md](./ARCHITECTURE.md)** for the full design, database
schema, payment-flow sequence diagram, and an honest list of what's built
vs. not yet.

## Quick start

```bash
cp .env.example .env
```

Fill in `.env`:
- `AUTH_SECRET` — generate with `openssl rand -base64 32`
- `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET`, `PAYPAL_WEBHOOK_ID` — from a
  free [PayPal Developer](https://developer.paypal.com) sandbox app
  (`PAYPAL_ENV=sandbox` is the default)
- Everything else has a working default (mock eSIM provider, console email)

```bash
npm install
npm run prisma:migrate   # creates the database schema
npm run seed              # countries, mock plans, a 40% markup rule, admin + demo accounts
npm run dev
```

Open http://localhost:3000.

## Testing the full flow locally

1. Log in as the seeded demo customer (`demo@lakhfif.example` /
   `demo12345`), or register a new account.
2. Buy any plan and pay with a [PayPal sandbox buyer
   account](https://developer.paypal.com/dashboard/accounts).
3. Since `ESIM_PROVIDER_MODE=mock` by default, the order is fulfilled
   immediately with a real-looking (fake) QR code, ICCID, and activation
   code — no real eSIM provider needed.
4. To point PayPal's real webhook at your machine during development, use
   the [PayPal webhook simulator](https://developer.paypal.com/dashboard/webhooks)
   or a tunnel (ngrok, etc.) to `/api/webhooks/paypal`.
5. To see the "payment received, still preparing" path, buy a plan whose
   id ends in `-delay`, `-fail`, or `-insufficient` — append that suffix to
   any seeded plan's id in the database, or see
   `src/services/esim/providers/mock-provider.ts` for the full list of test
   hooks.
6. Admin panel: [http://localhost:3000/admin/login](http://localhost:3000/admin/login),
   using `ADMIN_SEED_EMAIL` / `ADMIN_SEED_PASSWORD` from `.env`.

## Connecting a real eSIM aggregator later

1. Fill in `src/services/esim/providers/example-aggregator-provider.ts`
   with your chosen aggregator's real endpoints and response shapes (it's
   written as an annotated template for exactly this).
2. Add a row for it to the `Provider` table with the correct
   `BillingMode` (`PREPAID` / `POSTPAID` / `PAYMENT_SPLIT`).
3. Set `ESIM_PROVIDER_MODE=aggregator`, `ESIM_PROVIDER_API_KEY`, and
   `ESIM_PROVIDER_API_URL` in `.env`.
4. Nothing else changes — pricing, checkout, fulfillment, and the frontend
   all talk to the `ESIMProvider` interface, not a specific vendor.

## Scripts

| Command | What it does |
|---|---|
| `npm run dev` | Local dev server |
| `npm run build` / `npm run start` | Production build / run |
| `npm run prisma:migrate` | Create/update the database schema |
| `npm run prisma:studio` | Browse the database in Prisma Studio |
| `npm run seed` | Seed reference data + first admin/demo accounts |
| `npm run typecheck` | `tsc --noEmit` |

## Deploying

Any Node.js host that supports Next.js works. Before switching
`PAYPAL_ENV` to `live`:

1. Add production PayPal credentials and re-create the webhook
   subscription pointed at your real domain's `/api/webhooks/paypal`.
2. Add your real eSIM aggregator credentials (see above).
3. Review the pricing rules in the admin panel — the seed only adds one
   global 40% markup rule.
4. Set `APP_URL` to your real domain (used in email links, canonical
   URLs, and CSRF origin-checking — checkout and login will reject
   requests if this doesn't match your real domain).
5. Set `CRON_SECRET` and point your host's scheduled-task feature (Vercel
   Cron, a system crontab, etc.) at `POST /api/admin/cron/sweep-pending`
   with `Authorization: Bearer <CRON_SECRET>` every few minutes, so an
   order stuck in `PROVIDER_PENDING` gets retried automatically.
6. Test the whole flow once against PayPal sandbox on the production
   deployment before flipping to live.
